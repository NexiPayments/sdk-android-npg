package it.nexi.ngp.merchant.mocks;

import it.nexi.ngp.sdk.features.cardpayment.ThreeDSOrderRequest;
import it.nexi.ngp.sdk.shared.enums.ExemptionsSettings;
import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.RecurringSettings;

public class ThreeDSOrderMock {

    public static ThreeDSOrderRequest getMockedRequest() {
        Order order = OrderMock.getMockedRequest();
        RecurringSettings recurringSettings = RecurringSettingsMock.getMockedRequest();
        ExemptionsSettings exemptionsSettings = ExemptionsSettings.NO_PREFERENCE;

        return ThreeDSOrderRequest.builder()
                .order(order)
                .recurrence(recurringSettings)
                .exemptions(exemptionsSettings)
                .build();
    }
}
