package it.nexi.ngp.merchant.mocks;

import java.util.Random;

import it.nexi.ngp.sdk.features.hostedpaymentpage.CreateHostedOrderRequest;
import it.nexi.ngp.sdk.features.hostedpaymentpage.CreateHostedOrderWebViewRequest;
import it.nexi.ngp.sdk.shared.enums.ActionType;
import it.nexi.ngp.sdk.shared.enums.CaptureType;
import it.nexi.ngp.sdk.shared.enums.ExemptionsSettings;
import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.PaymentSession;
import it.nexi.ngp.sdk.shared.models.RecurringSettings;
import it.nexi.ngp.sdk.util.ObjectMapper;

public class CreateHostedOrderWebViewRequestMock {

    public static CreateHostedOrderWebViewRequest getMockedRequest(String hostname) {
        CreateHostedOrderRequest orderRequest = mockOrderRequest(hostname);
        return ObjectMapper.map(orderRequest, CreateHostedOrderWebViewRequest.class);
    }

    private static CreateHostedOrderRequest mockOrderRequest(String hostname) {

        //Order order = OrderMock.getMockedRequest();
        int randomId = new Random().nextInt(9999 - 1000 + 1) + 1000;
        Order order = Order.builder()
                .orderId("btid9999469852365147845" + randomId)
                .amount("1")
                //.installmentQty("0")
                .currency("EUR")
                //.customerId("mcid97239999")
                //.description("PC HP LP7812")
                //.customField("christmas promotion")
                .build();
        RecurringSettings recurring = RecurringSettingsMock.getMockedRequest();

        PaymentSession paymentsession = PaymentSession.builder()
                .actionType(ActionType.PAY)
                .amount("1")
                //.recurrence(recurring)
                //.captureType(CaptureType.EXPLICIT)
                //.exemptions(ExemptionsSettings.NO_PREFERENCE)
                .language("ita")
                //.resultUrl("https://" + hostname + "/phoenix-0.0/paymentserviceapi-demo/result.jsp")
                //.cancelUrl("https://" + hostname + "/phoenix-0.0/demo/npg-v1/cancel.jsp")
                //.notificationUrl("https://" + hostname + "/phoenix-0.0/demo/npg-v1/notification.jsp")
                .build();

        return CreateHostedOrderRequest.builder()
                .order(order)
                .paymentSession(paymentsession)
                .build();
    }
}
