package it.nexi.ngp.merchant.mocks;

import it.nexi.ngp.sdk.features.hostedpaymentpage.CreateHostedOrderRequest;
import it.nexi.ngp.sdk.features.hostedpaymentpage.CreateHostedOrderWebViewRequest;
import it.nexi.ngp.sdk.shared.enums.ActionType;
import it.nexi.ngp.sdk.shared.enums.CaptureType;
import it.nexi.ngp.sdk.shared.enums.ExemptionsSettings;
import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.PaymentSession;
import it.nexi.ngp.sdk.shared.models.RecurringSettings;
import it.nexi.ngp.sdk.util.ObjectMapper;

public class CreateHostedOrderWebViewRequestMock {

    public static CreateHostedOrderWebViewRequest getMockedRequest(String hostname) {
        CreateHostedOrderRequest orderRequest = mockOrderRequest(hostname);
        return ObjectMapper.map(orderRequest, CreateHostedOrderWebViewRequest.class);
    }

    private static CreateHostedOrderRequest mockOrderRequest(String hostname) {

        Order order = OrderMock.getMockedRequest();
        RecurringSettings recurring = RecurringSettingsMock.getMockedRequest();

        PaymentSession paymentsession = PaymentSession.builder()
                .actionType(ActionType.PAY)
                .amount("1")
                .recurrence(recurring)
                .captureType(CaptureType.EXPLICIT)
                .exemptions(ExemptionsSettings.NO_PREFERENCE)
                .language("ita")
                .resultUrl("https://" + hostname + "/phoenix-0.0/paymentserviceapi-demo/result.jsp")
                .cancelUrl("https://" + hostname + "/phoenix-0.0/demo/npg-v1/cancel.jsp")
                .notificationUrl("https://" + hostname + "/phoenix-0.0/demo/npg-v1/notification.jsp")
                .build();

        return CreateHostedOrderRequest.builder()
                .order(order)
                .paymentSession(paymentsession)
                .build();
    }
}
