package it.nexi.ngp.merchant.mocks;

import java.math.BigDecimal;
import java.util.List;
import java.util.Random;

import it.nexi.ngp.sdk.shared.models.Address;
import it.nexi.ngp.sdk.shared.models.CardHolderAccountInfo;
import it.nexi.ngp.sdk.shared.models.CustomerInfo;
import it.nexi.ngp.sdk.shared.models.Installment;
import it.nexi.ngp.sdk.shared.models.MerchantRiskIndicator;
import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.TermsAndConditions;
import it.nexi.ngp.sdk.shared.models.TransactionSummary;
import it.nexi.ngp.sdk.shared.models.TransactionSummaryAttribute;

public class OrderMock {
    public static Order getMockedRequest() {
        Address address = Address.builder()
                .name("Mario Rossi")
                .street("Piazza Maggiore, 1")
                .additionalInfo("Quinto Piano, Scala B")
                .city("Bologna")
                .postCode("40124")
                .province("BO")
                .country("ITA")
                .build();
        CardHolderAccountInfo cardHolderAccountInfo = CardHolderAccountInfo.builder()
                .chAccDate("2019-02-11")
                .chAccAgeIndicator("01")
                .chAccChangeDate("2019-02-11")
                .chAccChangeIndicator("01")
                .chAccPwChangeDate("2019-02-11")
                .chAccPwChangeIndicator("01")
                .nbPurchaseAccount(BigDecimal.valueOf(0))
                .destinationAddressUsageDate("2019-02-11")
                .destinationAddressUsageIndicator("01")
                .destinationNameIndicator("01")
                .txnActivityDay(BigDecimal.valueOf(0))
                .txnActivityYear(BigDecimal.valueOf(0))
                .provisionAttemptsDay(BigDecimal.valueOf(0))
                .suspiciousAccActivity("01")
                .paymentAccAgeDate("2019-02-11")
                .paymentAccIndicator("0")
                .build();
        MerchantRiskIndicator merchantRiskIndicator = MerchantRiskIndicator.builder()
                .deliveryEmail("john.doe@email.com")
                .deliveryTimeframe("01")
                .giftCardAmount(null)
                .giftCardCount(BigDecimal.valueOf(0))
                .preOrderDate("2019-02-11")
                .preOrderPurchaseIndicator("01")
                .reorderItemsIndicator("01")
                .shipIndicator("01")
                .build();
        CustomerInfo customerInfo = CustomerInfo.builder()
                .cardHolderName("Mauro Morandi")
                .cardHolderEmail("mauro.morandi@nexi.it")
                .billingAddress(address)
                .shippingAddress(address)
                .mobilePhoneCountryCode("+39")
                .mobilePhone("3280987654")
                .homePhone("+391231234567")
                .workPhone("+391231234567")
                .cardHolderAcctInfo(cardHolderAccountInfo)
                .merchantRiskIndicator(merchantRiskIndicator)
                .build();
        List<TransactionSummaryAttribute> summaryList = List.of(
                TransactionSummaryAttribute.builder()
                        .label("Number of people")
                        .value("4")
                        .build());
        List<TransactionSummary> transactionSummaries = List.of(
                TransactionSummary.builder()
                        .language("eng")
                        .summaryList(summaryList)
                        .build());
        List<Installment> installments = List.of(
                Installment.builder()
                        .date("2023-11-13")
                        .amount("1")
                        .build(),
                Installment.builder()
                        .date("2023-09-13")
                        .amount("1")
                        .build());
        TermsAndConditions termsAndConditionsIds = new TermsAndConditions();
        termsAndConditionsIds.add("16dd6ac6-0791-4c72-b362-85f77f1728a2");

        int randomId = new Random().nextInt(9999 - 1000 + 1) + 1000;
        return Order.builder()
                .orderId("btid9999469852365147845" + randomId)
                .amount("2")
                .installmentQty("0")
                .currency("EUR")
                .customerId("mcid97239999")
                .description("PC HP LP7812")
                .customField("christmas promotion")
                .customerInfo(customerInfo)
                .transactionSummary(transactionSummaries)
                .installments(installments)
                .termsAndConditionsIds(termsAndConditionsIds)
                .build();
    }
}
