package it.nexi.ngp.merchant;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import it.nexi.ngp.sdk.PaymentClient;
import it.nexi.ngp.sdk.features.cardpayment.ThreeDSOrderRequest;
import it.nexi.ngp.sdk.features.cardpayment.cardform.view.CardFormFull;

public class ThreeStepActivity extends AppCompatActivity {

    private static final int THREE_STEP_3DS_RESULT_CODE = 201;

    private CardFormFull mCardForm;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_card_payment_full);

        mCardForm = findViewById(R.id.card_form);
        mCardForm.setup(this);

        String hostname = getIntent().getStringExtra("hostname");
        String apiKey = getIntent().getStringExtra("apiKey");

        ThreeDSOrderRequest orderRequest = (ThreeDSOrderRequest) getIntent().getSerializableExtra("request");

        Button continueBtn = findViewById(R.id.continue_btn);
        continueBtn.setOnClickListener(view -> {
            try {
                new PaymentClient(hostname, apiKey)
                        .loadThreeStepPaymentPage(
                                this, mCardForm, orderRequest, THREE_STEP_3DS_RESULT_CODE);
            } catch (Exception e) {
                Log.e("ThreeStep", e.getMessage());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        setResult(resultCode, data);
        finish();
    }
}