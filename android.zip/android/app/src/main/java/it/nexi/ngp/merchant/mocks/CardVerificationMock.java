package it.nexi.ngp.merchant.mocks;

import it.nexi.ngp.sdk.features.cardverification.CardVerificationRequest;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.shared.models.Order;

public class CardVerificationMock {

    public static CardVerificationRequest getMockedRequest() {
        Order order = OrderMock.getMockedRequest();
        Card card = Card.builder()
                .pan("4349942499990906")
                .expiryDate("0423")
                .cvv("034")
                .build();

        return CardVerificationRequest.builder()
                .order(order)
                .card(card)
                .build();
    }
}
