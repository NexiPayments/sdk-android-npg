package it.nexi.ngp.merchant.mocks;

import it.nexi.ngp.sdk.shared.enums.RecurringAction;
import it.nexi.ngp.sdk.shared.enums.RecurringContractType;
import it.nexi.ngp.sdk.shared.models.RecurringSettings;

public class RecurringSettingsMock {

    public static  RecurringSettings getMockedRequest() {
        return RecurringSettings.builder()
                .action(RecurringAction.CONTRACT_CREATION)
                .contractId("C2834988")
                .contractType(RecurringContractType.MIT_SCHEDULED)
                .contractExpiryDate("2023-12-16")
                .contractFrequency("120")
                .build();
    }
}
