package it.nexi.ngp.merchant.mocks;

import it.nexi.ngp.sdk.features.moto.MotoRequest;
import it.nexi.ngp.sdk.shared.enums.CaptureType;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.shared.models.Order;

public class MotoMock {

    public static MotoRequest getMockedRequest() {
        Order order = OrderMock.getMockedRequest();
        Card card = Card.builder()
            .pan("4349942499990906")
            .expiryDate("0423")
            .cvv("034")
            .build();
        CaptureType captureType = CaptureType.EXPLICIT;

        return MotoRequest.builder()
            .order(order)
            .card(card)
            .captureType(captureType)
            .build();
    }
}
