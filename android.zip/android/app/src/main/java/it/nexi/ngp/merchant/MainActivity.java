package it.nexi.ngp.merchant;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;

import java.util.ArrayList;
import java.util.List;

import it.nexi.ngp.merchant.mocks.CardVerificationMock;
import it.nexi.ngp.merchant.mocks.CreateHostedOrderWebViewRequestMock;
import it.nexi.ngp.merchant.mocks.MotoMock;
import it.nexi.ngp.merchant.mocks.ThreeDSOrderMock;
import it.nexi.ngp.sdk.PaymentClient;
import it.nexi.ngp.sdk.features.cardpayment.ThreeDSOrderRequest;
import it.nexi.ngp.sdk.features.cardpayment.ThreeDSPaymentResponse;
import it.nexi.ngp.sdk.features.cardverification.CardVerificationRequest;
import it.nexi.ngp.sdk.features.cardverification.CardVerificationResponse;
import it.nexi.ngp.sdk.features.hostedpaymentpage.CreateHostedOrderResponse;
import it.nexi.ngp.sdk.features.hostedpaymentpage.CreateHostedOrderWebViewRequest;
import it.nexi.ngp.sdk.features.moto.MotoRequest;
import it.nexi.ngp.sdk.features.moto.MotoResponse;
import it.nexi.ngp.sdk.features.paymentmethods.PaymentMethod1;
import it.nexi.ngp.sdk.features.paymentmethods.PaymentMethodsResponse;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.shared.models.Operation;

public class MainActivity extends AppCompatActivity {

    //private static final String HOSTNAME = "ngwecomm-dev.nexi.it";
    private static final String HOSTNAME = "stg-ta.nexigroup.com";
    //private static final String X_API_KEY = "380b409c-9100-4ecd-b6a2-36f44aa30f94"; //DEV
    private static final String X_API_KEY = "9696e35f-1473-4fe3-bc12-bace83df970c"; //STG
    private static final String MOTO_X_API_KEY = "117d2827-2aed-45c4-8b56-f2e4e2f9942b";

    private static final int CARD_VERIFICATION_CODE = 100;
    private static final int PAYMENT_METHODS_CODE = 101;
    private static final int TWO_STEP_3DS_CODE = 200;
    private static final int THREE_STEP_3DS_CODE = 201;
    private static final int HPP_WEBVIEW_CODE = 300;
    private static final int HPP_NO_WEBVIEW_CODE = 301;
    private static final int MOTO_CODE = 400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (data == null) {
            Log.w("ActivityResult", "User canceled the ongoing operation.");
            return;
        }

        switch (requestCode) {
            case CARD_VERIFICATION_CODE:
                showCardVerificationResult(resultCode, data);
                break;
            case PAYMENT_METHODS_CODE:
                showPaymentMethodsResult(resultCode, data);
                break;
            case TWO_STEP_3DS_CODE:
                showTwoStepThreeDSResult(resultCode, data);
                break;
            case THREE_STEP_3DS_CODE:
                showThreeStepThreeDSResult(resultCode, data);
                break;
            case HPP_WEBVIEW_CODE:
                showHostedPaymentPageWebViewResult(resultCode, data);
                break;
            case HPP_NO_WEBVIEW_CODE:
                showHostedPaymentPageResult(resultCode, data);
                break;
            case MOTO_CODE:
                showMotoResult(resultCode, data);
                break;
        }
    }

    public void loadHostedPaymentPage(View view) {
        CreateHostedOrderWebViewRequest request = CreateHostedOrderWebViewRequestMock.getMockedRequest(HOSTNAME);

        try {
            Log.i("Request", request.toString());
            new PaymentClient(HOSTNAME, X_API_KEY).loadHostedPaymentPage(this, request, HPP_WEBVIEW_CODE);
        } catch (Exception e) {
            Log.e("PaymentClient", e.getMessage());
        }
    }

    public void createHostedPaymentPage(View view) {
        CreateHostedOrderWebViewRequest request = CreateHostedOrderWebViewRequestMock.getMockedRequest(HOSTNAME);

        try {
            new PaymentClient(HOSTNAME, X_API_KEY).createHostedPaymentPage(this, request, HPP_NO_WEBVIEW_CODE);
        } catch (Exception e) {
            Log.e("PaymentClient", e.getMessage());
        }
    }

    public void loadTwoStepPaymentPage(View view) {
        ThreeDSOrderRequest request = ThreeDSOrderMock.getMockedRequest();

        Intent intent = new Intent(this, TwoStepActivity.class);
        intent.putExtra("hostname", HOSTNAME);
        intent.putExtra("apiKey", X_API_KEY);
        intent.putExtra("request", request);

        startActivityForResult(intent, TWO_STEP_3DS_CODE);
    }

    public void loadTwoStepPaymentPageNoForm(View view) {
        ThreeDSOrderRequest request = ThreeDSOrderMock.getMockedRequest();
        Card card = Card.builder()
                .pan("5398322499900998")
                .expiryDate("0423")
                .cvv("234")
                .build();

        try {
            new PaymentClient(HOSTNAME, X_API_KEY)
                    .loadTwoStepPaymentPage(this, card, request, TWO_STEP_3DS_CODE);
        } catch (Exception e) {
            Log.e("TwoStep", e.getMessage());
        }
    }

    public void loadThreeStepPaymentPage(View view) {
        ThreeDSOrderRequest request = ThreeDSOrderMock.getMockedRequest();

        Intent intent = new Intent(this, ThreeStepActivity.class);
        intent.putExtra("hostname", HOSTNAME);
        intent.putExtra("apiKey", X_API_KEY);
        intent.putExtra("request", request);

        startActivityForResult(intent, THREE_STEP_3DS_CODE);
    }

    public void loadThreeStepPaymentPageNoForm(View view) {
        ThreeDSOrderRequest request = ThreeDSOrderMock.getMockedRequest();
        Card card = Card.builder()
                .pan("5398322499900998")
                .expiryDate("0423")
                .cvv("234")
                .build();

        try {
            new PaymentClient(HOSTNAME, X_API_KEY)
                    .loadThreeStepPaymentPage(this, card, request, THREE_STEP_3DS_CODE);
        } catch (Exception e) {
            Log.e("ThreeStep", e.getMessage());
        }
    }

    public void verifyCard(View view) {
        CardVerificationRequest request = CardVerificationMock.getMockedRequest();

        try {
            new PaymentClient(HOSTNAME, X_API_KEY).verifyCard(this, request, CARD_VERIFICATION_CODE);
        } catch (Exception e) {
            Log.e("PaymentClient", e.getMessage());
        }
    }

    public void getPaymentMethods(View view) {
        try {
            new PaymentClient(HOSTNAME, X_API_KEY).getPaymentMethods(this, PAYMENT_METHODS_CODE);
        } catch (Exception e) {
            Log.e("PaymentClient", e.getMessage());
        }
    }

    public void processMoto(View view) {
        MotoRequest request = MotoMock.getMockedRequest();

        try {
            new PaymentClient(HOSTNAME, MOTO_X_API_KEY).processMoto(this, request, MOTO_CODE);
        } catch (Exception e) {
            Log.e("PaymentClient", e.getMessage());
        }
    }

    private void showCardVerificationResult(int resultCode, Intent data) {
        CardVerificationRequest request = (CardVerificationRequest) data.getSerializableExtra("request");

        if (resultCode == RESULT_OK) {
            CardVerificationResponse response = (CardVerificationResponse) data.getSerializableExtra("response");

            Card card = request.getCard();
            String pan = card.getPan();
            String expireDate = card.getExpiryDate();
            String cvv = card.getCvv();
            String operationResult = response.getOperation().getOperationResult().toString();

            String message = "PAN: " + pan +
                    '\n' +
                    "Exp. Date: " + expireDate +
                    '\n' +
                    "CVV: " + cvv +
                    '\n' +
                    "Result: " + operationResult;

            showDialog("Card Verification OK", message);
            Log.i("CardVerification", response.toString());
        } else {
            Exception exception = (Exception) data.getSerializableExtra("exception");
            showDialog("Card Verification KO", exception.getMessage());
            Log.e("CardVerification", exception.getMessage());
        }
    }

    private void showPaymentMethodsResult(int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            PaymentMethodsResponse response = (PaymentMethodsResponse) data.getSerializableExtra("response");
            List<PaymentMethod1> paymentMethods = response.getPaymentMethods();
            List<String> circuits = new ArrayList<>();

            for (PaymentMethod1 paymentMethod : paymentMethods) {
                circuits.add(paymentMethod.getCircuit());
            }

            String message = String.join(", ", circuits);
            showDialog("Payment Methods OK", message);
            Log.i("PaymentMethods", message);
        } else {
            Exception exception = (Exception) data.getSerializableExtra("exception");
            showDialog("Payment Methods KO", exception.getMessage());
            Log.e("PaymentMethods", exception.getMessage());
        }
    }

    private void showTwoStepThreeDSResult(int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            ThreeDSPaymentResponse response = (ThreeDSPaymentResponse) data.getSerializableExtra("response");
            showDialog("ThreeDS Payment OK", response.getOperation().toString());
            Log.i("TwoStepThreeDS", response.getOperation().toString());
        } else {
            Exception exception = (Exception) data.getSerializableExtra("exception");
            showDialog("ThreeDS Payment KO", exception.getMessage());
            Log.e("TwoStepThreeDS", exception.getMessage());
        }
    }

    private void showThreeStepThreeDSResult(int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            ThreeDSPaymentResponse response = (ThreeDSPaymentResponse) data.getSerializableExtra("response");
            showDialog("ThreeDS Payment OK", response.getOperation().toString());
            Log.i("ThreeStepThreeDS", response.getOperation().toString());
        } else {
            Exception exception = (Exception) data.getSerializableExtra("exception");
            showDialog("ThreeDS Payment KO", exception.getMessage());
            Log.e("ThreeStepThreeDS", exception.getMessage());
        }
    }

    private void showHostedPaymentPageWebViewResult(int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            Operation response = (Operation) data.getSerializableExtra("response");
            showDialog("HPP OK", response.toString());
            Log.i("HPP", response.toString());
        } else {
            Exception exception = (Exception) data.getSerializableExtra("exception");
            showDialog("HPP KO", exception.getMessage());
            Log.e("HPP", exception.getMessage());
        }
    }

    private void showHostedPaymentPageResult(int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            CreateHostedOrderResponse response = (CreateHostedOrderResponse) data.getSerializableExtra("response");
            String message = "Hosted Page: " + response.getHostedPage()
                    + '\n'
                    + "Security Token: " + response.getSecurityToken();
            showDialog("HPP OK", message);
            Log.i("HPP", message);
        } else {
            Exception exception = (Exception) data.getSerializableExtra("exception");
            showDialog("HPP KO", exception.getMessage());
            Log.e("HPP", exception.getMessage());
        }
    }

    private void showMotoResult(int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            MotoResponse response = (MotoResponse) data.getSerializableExtra("response");
            showDialog("M.O.T.O. OK", response.toString());
            Log.i("M.O.T.O.", response.toString());
        } else {
            Exception exception = (Exception) data.getSerializableExtra("exception");
            showDialog("M.O.T.O. KO", exception.getMessage());
            Log.e("M.O.T.O.", exception.getMessage());
        }
    }

    private void showDialog(String title, String message) {
        new AlertDialog.Builder(this)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(android.R.string.ok, null)
                .show();
    }
}