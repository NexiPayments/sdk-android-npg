package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import it.nexi.ngp.sdk.shared.enums.ActionType;
import it.nexi.ngp.sdk.shared.enums.CaptureType;
import it.nexi.ngp.sdk.shared.enums.ExemptionsSettings;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaymentSession {

    @SerializedName("actionType")
    private ActionType actionType;

    @SerializedName("amount")
    private String amount;

    @SerializedName("recurrence")
    private RecurringSettings recurrence;

    @SerializedName("captureType")
    private CaptureType captureType;

    @SerializedName("exemptions")
    private ExemptionsSettings exemptions;

    @SerializedName("language")
    private String language = "ita";

    @SerializedName("resultUrl")
    private String resultUrl;

    @SerializedName("cancelUrl")
    private String cancelUrl;

    @SerializedName("notificationUrl")
    private String notificationUrl;

    public PaymentSession actionType(ActionType actionType) {
        this.actionType = actionType;
        return this;
    }

    public PaymentSession amount(String amount) {
        this.amount = amount;
        return this;
    }

    public PaymentSession recurrence(RecurringSettings recurrence) {
        this.recurrence = recurrence;
        return this;
    }

    public PaymentSession captureType(CaptureType captureType) {
        this.captureType = captureType;
        return this;
    }

    public PaymentSession exemptions(ExemptionsSettings exemptions) {
        this.exemptions = exemptions;
        return this;
    }

    public PaymentSession language(String language) {
        this.language = language;
        return this;
    }

    public PaymentSession resultUrl(String resultUrl) {
        this.resultUrl = resultUrl;
        return this;
    }

    public PaymentSession cancelUrl(String cancelUrl) {
        this.cancelUrl = cancelUrl;
        return this;
    }

    public PaymentSession notificationUrl(String notificationUrl) {
        this.notificationUrl = notificationUrl;
        return this;
    }
}
