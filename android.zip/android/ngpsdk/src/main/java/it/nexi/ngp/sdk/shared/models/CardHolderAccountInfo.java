package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CardHolderAccountInfo implements Serializable {

    @SerializedName("chAccDate")
    private String chAccDate;

    @SerializedName("chAccAgeIndicator")
    private String chAccAgeIndicator;

    @SerializedName("chAccChangeDate")
    private String chAccChangeDate;

    @SerializedName("chAccChangeIndicator")
    private String chAccChangeIndicator;

    @SerializedName("chAccPwChangeDate")
    private String chAccPwChangeDate;

    @SerializedName("chAccPwChangeIndicator")
    private String chAccPwChangeIndicator;

    @SerializedName("nbPurchaseAccount")
    private BigDecimal nbPurchaseAccount;

    @SerializedName("destinationAddressUsageDate")
    private String destinationAddressUsageDate;

    @SerializedName("destinationAddressUsageIndicator")
    private String destinationAddressUsageIndicator;

    @SerializedName("destinationNameIndicator")
    private String destinationNameIndicator;

    @SerializedName("txnActivityDay")
    private BigDecimal txnActivityDay;

    @SerializedName("txnActivityYear")
    private BigDecimal txnActivityYear;

    @SerializedName("provisionAttemptsDay")
    private BigDecimal provisionAttemptsDay;

    @SerializedName("suspiciousAccActivity")
    private String suspiciousAccActivity;

    @SerializedName("paymentAccAgeDate")
    private String paymentAccAgeDate;

    @SerializedName("paymentAccIndicator")
    private String paymentAccIndicator;

    public CardHolderAccountInfo chAccDate(String chAccDate) {
        this.chAccDate = chAccDate;
        return this;
    }

    public CardHolderAccountInfo chAccAgeIndicator(String chAccAgeIndicator) {
        this.chAccAgeIndicator = chAccAgeIndicator;
        return this;
    }

    public CardHolderAccountInfo chAccChangeDate(String chAccChangeDate) {
        this.chAccChangeDate = chAccChangeDate;
        return this;
    }

    public CardHolderAccountInfo chAccChangeIndicator(String chAccChangeIndicator) {
        this.chAccChangeIndicator = chAccChangeIndicator;
        return this;
    }

    public CardHolderAccountInfo chAccPwChangeDate(String chAccPwChangeDate) {
        this.chAccPwChangeDate = chAccPwChangeDate;
        return this;
    }

    public CardHolderAccountInfo chAccPwChangeIndicator(String chAccPwChangeIndicator) {
        this.chAccPwChangeIndicator = chAccPwChangeIndicator;
        return this;
    }

    public CardHolderAccountInfo nbPurchaseAccount(BigDecimal nbPurchaseAccount) {
        this.nbPurchaseAccount = nbPurchaseAccount;
        return this;
    }

    public CardHolderAccountInfo destinationAddressUsageDate(String destinationAddressUsageDate) {
        this.destinationAddressUsageDate = destinationAddressUsageDate;
        return this;
    }

    public CardHolderAccountInfo destinationAddressUsageIndicator(String destinationAddressUsageIndicator) {
        this.destinationAddressUsageIndicator = destinationAddressUsageIndicator;
        return this;
    }

    public CardHolderAccountInfo destinationNameIndicator(String destinationNameIndicator) {
        this.destinationNameIndicator = destinationNameIndicator;
        return this;
    }

    public CardHolderAccountInfo txnActivityDay(BigDecimal txnActivityDay) {
        this.txnActivityDay = txnActivityDay;
        return this;
    }

    public CardHolderAccountInfo txnActivityYear(BigDecimal txnActivityYear) {
        this.txnActivityYear = txnActivityYear;
        return this;
    }

    public CardHolderAccountInfo provisionAttemptsDay(BigDecimal provisionAttemptsDay) {
        this.provisionAttemptsDay = provisionAttemptsDay;
        return this;
    }

    public CardHolderAccountInfo suspiciousAccActivity(String suspiciousAccActivity) {
        this.suspiciousAccActivity = suspiciousAccActivity;
        return this;
    }

    public CardHolderAccountInfo paymentAccAgeDate(String paymentAccAgeDate) {
        this.paymentAccAgeDate = paymentAccAgeDate;
        return this;
    }

    public CardHolderAccountInfo paymentAccIndicator(String paymentAccIndicator) {
        this.paymentAccIndicator = paymentAccIndicator;
        return this;
    }
}
