package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TransactionSummaryAttribute implements Serializable {

    @SerializedName("label")
    private String label;

    @SerializedName("value")
    private String value;

    public TransactionSummaryAttribute label(String label) {
        this.label = label;
        return this;
    }

    public TransactionSummaryAttribute value(String value) {
        this.value = value;
        return this;
    }
}
