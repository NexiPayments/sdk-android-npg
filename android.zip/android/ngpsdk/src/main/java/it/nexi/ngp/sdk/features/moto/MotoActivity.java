package it.nexi.ngp.sdk.features.moto;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import it.nexi.ngp.sdk.R;
import it.nexi.ngp.sdk.util.Result;

public class MotoActivity
    extends AppCompatActivity
    implements MotoContracts.View
{

    private TextView text;
    private ProgressBar progressBar;

    private MotoContracts.Presenter presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moto);

        text = findViewById(R.id.text_view);
        progressBar = findViewById(R.id.progress_bar);

        presenter = new MotoPresenter(this);

        MotoRequest motoRequest =
                (MotoRequest) getIntent().getSerializableExtra("request");
        presenter.processMoto(motoRequest);
    }

    @Override
    public void showProgress() {
        text.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void showResult(final Result<MotoResponse> result) {
        text.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.INVISIBLE);

        Intent intent = new Intent();
        intent.putExtra("request", getIntent().getSerializableExtra("request"));

        if (result instanceof Result.Success) {
            MotoResponse response = ((Result.Success<MotoResponse>) result).data;
            intent.putExtra("response", response);
            setResult(RESULT_OK, intent);
        } else {
            Exception exception = ((Result.Error<MotoResponse>) result).exception;
            intent.putExtra("exception", exception);
            setResult(RESULT_CANCELED, intent);
        }

        finish();
    }
}
