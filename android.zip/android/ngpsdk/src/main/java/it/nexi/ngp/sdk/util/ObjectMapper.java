package it.nexi.ngp.sdk.util;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

public class ObjectMapper {

    public static <T> T map(Object object, Class<T> clazz) {
        Gson gson = new GsonBuilder().create();
        String json = gson.toJson(object);
        return gson.fromJson(json, clazz);
    }
}