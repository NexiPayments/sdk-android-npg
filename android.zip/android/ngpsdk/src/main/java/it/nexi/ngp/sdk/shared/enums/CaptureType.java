package it.nexi.ngp.sdk.shared.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(CaptureType.Adapter.class)
public enum CaptureType {

    IMPLICIT("IMPLICIT"),
    EXPLICIT("EXPLICIT");

    private String value;

    CaptureType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static CaptureType fromValue(String input) {
        for (CaptureType b : CaptureType.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<CaptureType> {
        @Override
        public void write(final JsonWriter jsonWriter, final CaptureType enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public CaptureType read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return CaptureType.fromValue((String) (value));
        }
    }
}
