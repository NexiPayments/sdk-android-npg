package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.models.Operation;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSInitResponse implements Serializable {

    @SerializedName("operation")
    private Operation operation;

    @SerializedName("threeDSEnrollmentStatus")
    private String threeDSEnrollmentStatus;

    @SerializedName("threeDSAuthRequest")
    private String threeDSAuthRequest;

    @SerializedName("threeDSAuthUrl")
    private String threeDSAuthUrl;

    public ThreeDSInitResponse operation(Operation operation) {
        this.operation = operation;
        return this;
    }

    public ThreeDSInitResponse threeDSEnrollmentStatus(String threeDSEnrollmentStatus) {
        this.threeDSEnrollmentStatus = threeDSEnrollmentStatus;
        return this;
    }

    public ThreeDSInitResponse threeDSAuthRequest(String threeDSAuthRequest) {
        this.threeDSAuthRequest = threeDSAuthRequest;
        return this;
    }

    public ThreeDSInitResponse threeDSAuthUrl(String threeDSAuthUrl) {
        this.threeDSAuthUrl = threeDSAuthUrl;
        return this;
    }
}
