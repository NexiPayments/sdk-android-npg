package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TransactionSummary implements Serializable {

    @SerializedName("language")
    private String language;

    @SerializedName("summaryList")
    private List<TransactionSummaryAttribute> summaryList;

    public TransactionSummary language(String language) {
        this.language = language;
        return this;
    }

    public TransactionSummary summaryList(List<TransactionSummaryAttribute> summaryList) {
        this.summaryList = summaryList;
        return this;
    }

    public TransactionSummary addSummaryListItem(TransactionSummaryAttribute summaryListItem) {
        if (this.summaryList == null) {
            this.summaryList = new ArrayList<TransactionSummaryAttribute>();
        }
        this.summaryList.add(summaryListItem);
        return this;
    }
}
