package it.nexi.ngp.sdk.shared.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.io.Serializable;

@JsonAdapter(ChannelType.Adapter.class)
public enum ChannelType implements Serializable {

    ECOMMERCE("ECOMMERCE"),
    POS("POS"),
    BACKOFFICE("BACKOFFICE");

    private String value;

    ChannelType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ChannelType fromValue(String input) {
        for (ChannelType b : ChannelType.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<ChannelType> {
        @Override
        public void write(final JsonWriter jsonWriter, final ChannelType enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public ChannelType read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return ChannelType.fromValue((String) (value));
        }
    }
}
