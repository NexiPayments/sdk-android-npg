package it.nexi.ngp.sdk.features.hostedpaymentpage;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class HostedPaymentPageWebViewClient extends WebViewClient {

    private final Uri resultUri;
    private final Uri cancelUri;
    private final HostedPaymentPageContracts.Presenter.Callback callback;

    public HostedPaymentPageWebViewClient(
        final String resultUrl,
        final String cancelUrl,
        final HostedPaymentPageContracts.Presenter.Callback callback)
    {
        this.resultUri = Uri.parse(resultUrl);
        this.cancelUri = Uri.parse(cancelUrl);
        this.callback = callback;
    }

    @Override
    public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
        String requestPath = request.getUrl().getPath();
        String resultPath = resultUri.getPath();
        String cancelPath = cancelUri.getPath();

        if (requestPath.equals(resultPath)) {
            callback.onActionDone(Activity.RESULT_OK);
        }

        if (requestPath.equals(cancelPath)) {
            callback.onActionDone(Activity.RESULT_CANCELED);
        }

        return super.shouldOverrideUrlLoading(view, request);
    }
}
