package it.nexi.ngp.sdk.features.cardpayment;

import android.webkit.WebView;
import android.webkit.WebViewClient;

public class CardPaymentWebViewClient extends WebViewClient {

    private final String returnUrl;
    private final CardPaymentContracts.Presenter.Callback callback;

    public CardPaymentWebViewClient(
            String returnUrl,
            CardPaymentContracts.Presenter.Callback callback) {
        this.returnUrl = returnUrl;
        this.callback = callback;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        if (url.equals(returnUrl)) {
            callback.onActionDone();
        }

        super.onPageFinished(view, url);
    }
}
