package it.nexi.ngp.sdk.io;

public class UnexpectedStatusCodeException extends Exception {

    public UnexpectedStatusCodeException(String message) {
        super(message);
    }

    public UnexpectedStatusCodeException(String message, Throwable cause) {
        super(message, cause);
    }
}
