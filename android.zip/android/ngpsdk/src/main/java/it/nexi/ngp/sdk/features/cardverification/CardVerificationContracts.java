package it.nexi.ngp.sdk.features.cardverification;

import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;

class CardVerificationContracts {

    interface View {
        void showProgress();
        void showResult(final Result<CardVerificationResponse> result);
    }

    interface Presenter {
        void verifyCard(final CardVerificationRequest request);
    }

    interface Repository {
        void verifyCard(
            final CardVerificationRequest request,
            final RepositoryCallback<CardVerificationResponse> callback);
    }
}
