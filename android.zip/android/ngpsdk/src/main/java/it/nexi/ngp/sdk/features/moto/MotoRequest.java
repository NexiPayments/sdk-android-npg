package it.nexi.ngp.sdk.features.moto;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.enums.CaptureType;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.shared.models.Order;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MotoRequest implements Serializable {

    @SerializedName("order")
    private Order order;

    @SerializedName("card")
    private Card card;

    @SerializedName("captureType")
    private CaptureType captureType;

    public MotoRequest order(Order order) {
        this.order = order;
        return this;
    }

    public MotoRequest card(Card card) {
        this.card = card;
        return this;
    }

    public MotoRequest captureType(CaptureType captureType) {
        this.captureType = captureType;
        return this;
    }
}
