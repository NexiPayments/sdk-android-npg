package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSValidationRequest implements Serializable {

    @SerializedName("operationId")
    private String operationId;

    @SerializedName("threeDSAuthResponse")
    private String threeDSAuthResponse;

    public ThreeDSValidationRequest operationId(String operationId) {
        this.operationId = operationId;
        return this;
    }

    public ThreeDSValidationRequest threeDSAuthResponse(String threeDSAuthResponse) {
        this.threeDSAuthResponse = threeDSAuthResponse;
        return this;
    }
}
