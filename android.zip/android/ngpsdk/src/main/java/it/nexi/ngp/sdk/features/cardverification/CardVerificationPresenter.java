package it.nexi.ngp.sdk.features.cardverification;

class CardVerificationPresenter implements CardVerificationContracts.Presenter {

    private final CardVerificationContracts.View view;
    private final CardVerificationContracts.Repository repository;

    CardVerificationPresenter(CardVerificationContracts.View view) {
        this.view = view;
        this.repository = new CardVerificationRepository();
    }

    @Override
    public void verifyCard(final CardVerificationRequest request) {
        view.showProgress();
        repository.verifyCard(request, view::showResult);
    }
}
