package it.nexi.ngp.sdk.shared.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.io.Serializable;

@JsonAdapter(OperationResult.Adapter.class)
public enum OperationResult implements Serializable {

    AUTHORIZED("AUTHORIZED"),
    EXECUTED("EXECUTED"),
    DECLINED("DECLINED"),
    DENIED_BY_RISK("DENIED_BY_RISK"),
    THREEDS_VALIDATED("THREEDS_VALIDATED"),
    THREEDS_FAILED("THREEDS_FAILED"),
    PENDING("PENDING"),
    CANCELED("CANCELED"),
    VOIDED("VOIDED"),
    REFUNDED("REFUNDED"),
    FAILED("FAILED");

    private String value;

    OperationResult(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static OperationResult fromValue(String input) {
        for (OperationResult b : OperationResult.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<OperationResult> {
        @Override
        public void write(final JsonWriter jsonWriter, final OperationResult enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public OperationResult read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return OperationResult.fromValue((String) (value));
        }
    }
}
