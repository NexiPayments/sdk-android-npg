package it.nexi.ngp.sdk;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaymentClientConfig {

    private static volatile PaymentClientConfig instance;
    private static Object mutex = new Object();

    private String hostname;
    private String apiKey;

    private PaymentClientConfig() {
    }

    public static PaymentClientConfig getInstance() {
        PaymentClientConfig result = instance;
        if (result == null) {
            synchronized (mutex) {
                result = instance;
                if (result == null)
                    instance = result = new PaymentClientConfig();
            }
        }
        return result;
    }
}
