package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderDetails {

    @SerializedName("orderStatus")
    private OrderStatus orderStatus;

    @SerializedName("operations")
    private List<Operation> operations;

    @SerializedName("paymentLinks")
    private List<PaymentLink> paymentLinks;

    public OrderDetails orderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
        return this;
    }

    public OrderDetails operations(List<Operation> operations) {
        this.operations = operations;
        return this;
    }

    public OrderDetails addOperationsItem(Operation operationsItem) {
        if (this.operations == null) {
            this.operations = new ArrayList<Operation>();
        }
        this.operations.add(operationsItem);
        return this;
    }

    public OrderDetails paymentLinks(List<PaymentLink> paymentLinks) {
        this.paymentLinks = paymentLinks;
        return this;
    }

    public OrderDetails addPaymentLinksItem(PaymentLink paymentLinksItem) {
        if (this.paymentLinks == null) {
            this.paymentLinks = new ArrayList<PaymentLink>();
        }
        this.paymentLinks.add(paymentLinksItem);
        return this;
    }
}
