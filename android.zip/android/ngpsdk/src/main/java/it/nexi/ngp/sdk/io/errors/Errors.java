package it.nexi.ngp.sdk.io.errors;

import androidx.annotation.NonNull;

import java.util.ArrayList;

import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
public class Errors extends ArrayList<ErrorsInner> {

    @NonNull
    @Override
    public String toString() {
        return "Errors {\n" +
                "    " + toIndentedString(super.toString()) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }
}
