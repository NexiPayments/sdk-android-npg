package it.nexi.ngp.sdk.io;

public class InvalidApiKeyException extends Exception {

    public InvalidApiKeyException(String message) {
        super(message);
    }

    public InvalidApiKeyException(String message, Throwable cause) {
        super(message, cause);
    }
}
