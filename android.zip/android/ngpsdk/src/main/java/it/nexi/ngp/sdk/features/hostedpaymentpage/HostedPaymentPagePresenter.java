package it.nexi.ngp.sdk.features.hostedpaymentpage;

import it.nexi.ngp.sdk.util.ObjectMapper;
import it.nexi.ngp.sdk.util.Result;

public class HostedPaymentPagePresenter implements HostedPaymentPageContracts.Presenter {

    private final HostedPaymentPageContracts.View view;
    private final HostedPaymentPageContracts.Repository repository;

    private final String resultUrl = "https://npg.sdk.it/hpp/result";
    private final String cancelUrl = "https://npg.sdk.it/hpp/cancel";

    public HostedPaymentPagePresenter(HostedPaymentPageContracts.View view) {
        this.view = view;
        this.repository = new HostedPaymentPageRepository();
    }

    @Override
    public void initHostedPaymentPage(
        final CreateHostedOrderWebViewRequest request,
        final boolean includeWebView)
    {
        view.showProgress();

        CreateHostedOrderRequest orderRequest = ObjectMapper.map(request, CreateHostedOrderRequest.class);
        orderRequest.getPaymentSession().setResultUrl(resultUrl);
        orderRequest.getPaymentSession().setCancelUrl(cancelUrl);

        repository.initHostedPaymentPage(orderRequest, result -> {
            if (result instanceof Result.Success) {
                if (!includeWebView) {
                    view.showInitResult(result);
                    return;
                }

                CreateHostedOrderResponse response = ((Result.Success<CreateHostedOrderResponse>) result).data;
                view.showWebView(orderRequest, response, resultUrl, cancelUrl);
            } else {
                view.showInitResult(result);
            }
        });
    }

    @Override
    public void getOperationResult(final String orderId) {
        view.showProgress();

        repository.getOperationResult(orderId, result -> {
            if (result instanceof Result.Success) {
                view.showOperationResult(result);
            } else {
                view.showOperationResult(result);
            }
        });
    }
}
