package it.nexi.ngp.sdk.shared.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(RecurringContractType.Adapter.class)
public enum RecurringContractType {

    MIT_UNSCHEDULED("MIT_UNSCHEDULED"),
    MIT_SCHEDULED("MIT_SCHEDULED"),
    CIT("CIT");

    private String value;

    RecurringContractType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static RecurringContractType fromValue(String input) {
        for (RecurringContractType b : RecurringContractType.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<RecurringContractType> {
        @Override
        public void write(final JsonWriter jsonWriter, final RecurringContractType enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public RecurringContractType read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return RecurringContractType.fromValue((String) (value));
        }
    }
}
