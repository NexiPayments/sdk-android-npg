package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.models.Operation;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSValidationResponse implements Serializable {

    @SerializedName("operation")
    private Operation operation;

    @SerializedName("threeDSAuthResult")
    private ThreeDSAuthResult threeDSAuthResult;

    public ThreeDSValidationResponse operation(Operation operation) {
        this.operation = operation;
        return this;
    }

    public ThreeDSValidationResponse threeDSAuthResult(ThreeDSAuthResult threeDSAuthResult) {
        this.threeDSAuthResult = threeDSAuthResult;
        return this;
    }
}
