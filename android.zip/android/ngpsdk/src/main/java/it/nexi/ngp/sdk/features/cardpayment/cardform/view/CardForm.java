package it.nexi.ngp.sdk.features.cardpayment.cardform.view;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build.VERSION_CODES;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;

import androidx.annotation.DrawableRes;
import androidx.annotation.IntDef;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import com.google.android.material.textfield.TextInputEditText;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

import it.nexi.ngp.sdk.R;
import it.nexi.ngp.sdk.features.cardpayment.CardPaymentActivity;
import it.nexi.ngp.sdk.features.cardpayment.cardform.OnCardFormFieldFocusedListener;
import it.nexi.ngp.sdk.features.cardpayment.cardform.OnCardFormSubmitListener;
import it.nexi.ngp.sdk.features.cardpayment.cardform.OnCardFormValidListener;
import it.nexi.ngp.sdk.features.cardpayment.cardform.utils.CardType;
import it.nexi.ngp.sdk.features.cardpayment.cardform.utils.ViewUtils;
import it.nexi.ngp.sdk.features.cardpayment.cardform.view.CardEditText.OnCardTypeChangedListener;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.features.cardpayment.ThreeDSOrderRequest;

public abstract class CardForm extends LinearLayout implements OnCardTypeChangedListener, OnFocusChangeListener, OnClickListener,
        OnEditorActionListener, TextWatcher {

    /**
     * Hides the field.
     */
    public static final int FIELD_DISABLED = 0;

    /**
     * Shows the field, and makes the field optional.
     */
    public static final int FIELD_OPTIONAL = 1;

    /**
     * Shows the field, and require the field value to be non empty when validating the card form.
     */
    public static final int FIELD_REQUIRED = 2;

    /**
     * The statuses a field can be.
     */
    @Retention(RetentionPolicy.SOURCE)
    @IntDef({FIELD_DISABLED, FIELD_OPTIONAL, FIELD_REQUIRED})
    @interface FieldStatus {
    }

    protected List<ErrorEditText> mVisibleEditTexts;

    protected ImageView mCardNumberIcon;
    protected CardEditText mCardNumber;
    protected ExpirationDateEditText mExpiration;
    protected CvvEditText mCvv;
    protected CardholderNameEditText mCardholderName;
    protected ImageView mCardholderNameIcon;
    protected ImageView mPostalCodeIcon;
    protected PostalCodeEditText mPostalCode;
    protected ImageView mMobileNumberIcon;
    protected CountryCodeEditText mCountryCode;
    protected MobileNumberEditText mMobileNumber;
    protected TextView mMobileNumberExplanation;
    protected InitialValueCheckBox mSaveCardCheckBox;

    private boolean mCardNumberRequired = true;
    private boolean mExpirationRequired = true;
    private boolean mCvvRequired = true;
    private int mCardholderNameStatus = FIELD_DISABLED;
    private boolean mPostalCodeRequired;
    private boolean mMobileNumberRequired;
    private String mActionLabel;
    private boolean mSaveCardCheckBoxVisible;
    private boolean mSaveCardCheckBoxChecked;

    private boolean mValid = false;

    private OnCardFormValidListener mOnCardFormValidListener;
    private OnCardFormSubmitListener mOnCardFormSubmitListener;
    private OnCardFormFieldFocusedListener mOnCardFormFieldFocusedListener;
    private OnCardTypeChangedListener mOnCardTypeChangedListener;

    public CardForm(Context context) {
        super(context);
        init();
    }

    public CardForm(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CardForm(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init();
    }

    @TargetApi(VERSION_CODES.LOLLIPOP)
    public CardForm(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init();
    }

    abstract void init();

    /**
     * @param required {@code true} to show and require a credit card number, {@code false} otherwise. Defaults to {@code false}.
     * @return {@link CardForm} for method chaining
     */
    private CardForm cardRequired(boolean required) {
        mCardNumberRequired = required;
        return this;
    }

    /**
     * @param required {@code true} to show and require an expiration date, {@code false} otherwise. Defaults to {@code false}.
     * @return {@link CardForm} for method chaining
     */
    private CardForm expirationRequired(boolean required) {
        mExpirationRequired = required;
        return this;
    }

    /**
     * @param required {@code true} to show and require a cvv, {@code false} otherwise. Defaults to {@code false}.
     * @return {@link CardForm} for method chaining
     */
    private CardForm cvvRequired(boolean required) {
        mCvvRequired = required;
        return this;
    }

    /**
     * @param cardHolderNameStatus can be one of the {@link FieldStatus} options.
     *                             - {@link CardForm#FIELD_DISABLED} to hide this field. This is the default option.
     *                             - {@link CardForm#FIELD_OPTIONAL} to show this field but make it an optional field.
     *                             - {@link CardForm#FIELD_REQUIRED} to show this field and make it required to validate the card form.
     * @return {@link CardForm} for method chaining
     */
    private CardForm cardholderName(@FieldStatus int cardHolderNameStatus) {
        mCardholderNameStatus = cardHolderNameStatus;
        return this;
    }

    /**
     * @param required {@code true} to show and require a postal code, {@code false} otherwise. Defaults to {@code false}.
     * @return {@link CardForm} for method chaining
     */
    private CardForm postalCodeRequired(boolean required) {
        mPostalCodeRequired = required;
        return this;
    }

    /**
     * @param required {@code true} to show and require a mobile number, {@code false} otherwise. Defaults to {@code false}.
     * @return {@link CardForm} for method chaining
     */
    private CardForm mobileNumberRequired(boolean required) {
        mMobileNumberRequired = required;
        return this;
    }

    /**
     * @param actionLabel the {@link String} to display to the user to submit the form from the keyboard
     * @return {@link CardForm} for method chaining
     */
    private CardForm actionLabel(String actionLabel) {
        mActionLabel = actionLabel;
        return this;
    }

    /**
     * @param mobileNumberExplanation the {@link String} to display below the mobile number input
     * @return {@link CardForm} for method chaining
     */
    private CardForm mobileNumberExplanation(String mobileNumberExplanation) {
        mMobileNumberExplanation.setText(mobileNumberExplanation);
        return this;
    }

    /**
     * @param mask if {@code true}, card number input will be masked.
     */
    private CardForm maskCardNumber(boolean mask) {
        mCardNumber.setMask(mask);
        return this;
    }

    /**
     * @param mask if {@code true}, CVV input will be masked.
     */
    private CardForm maskCvv(boolean mask) {
        mCvv.setMask(mask);
        return this;
    }

    /**
     * @param visible Determines if the save card CheckBox should be shown. Defaults to hidden / {@code false}
     * @return {@link CardForm} for method chaining
     */
    private CardForm saveCardCheckBoxVisible(boolean visible) {
        mSaveCardCheckBoxVisible = visible;
        return this;
    }

    /**
     * @param checked The default value for the Save Card CheckBox.
     * @return {@link CardForm} for method chaining
     */
    private CardForm saveCardCheckBoxChecked(boolean checked) {
        mSaveCardCheckBoxChecked = checked;
        return this;
    }


    /**
     * Sets up the card form for display to the user using the values provided in {@link CardForm#cardRequired(boolean)},
     * {@link CardForm#expirationRequired(boolean)}, ect. If {@link CardForm#setup(AppCompatActivity)}
     * or {@link CardForm#setup(FragmentActivity)} is not called, the form will not be visible.
     *
     * @param activity Used to set {@link WindowManager.LayoutParams#FLAG_SECURE} to prevent screenshots
     */
    public void setup(AppCompatActivity activity) {
        setup((FragmentActivity) activity);
    }

    /**
     * Sets up the card form for display to the user using the values provided in {@link CardForm#cardRequired(boolean)},
     * {@link CardForm#expirationRequired(boolean)}, ect. If {@link CardForm#setup(AppCompatActivity)}
     * or {@link CardForm#setup(FragmentActivity)} is not called, the form will not be visible.
     *
     * @param activity Used to set {@link WindowManager.LayoutParams#FLAG_SECURE} to prevent screenshots
     */
    public void setup(FragmentActivity activity) {
        activity.getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE,
                WindowManager.LayoutParams.FLAG_SECURE);

        boolean cardHolderNameVisible = mCardholderNameStatus != FIELD_DISABLED;
        boolean isDarkBackground = ViewUtils.isDarkBackground(activity);
        mCardholderNameIcon.setImageResource(isDarkBackground ? R.drawable.ic_cardholder_name_dark : R.drawable.ic_cardholder_name);
        mCardNumberIcon.setImageResource(isDarkBackground ? R.drawable.ic_card_dark : R.drawable.ic_card);
        mPostalCodeIcon.setImageResource(isDarkBackground ? R.drawable.ic_postal_code_dark : R.drawable.ic_postal_code);
        mMobileNumberIcon.setImageResource(isDarkBackground ? R.drawable.ic_mobile_number_dark : R.drawable.ic_mobile_number);

//        setViewVisibility(mCardholderNameIcon, cardHolderNameVisible);
        setViewVisibility(mCardholderNameIcon, false);
//        setFieldVisibility(mCardholderName, cardHolderNameVisible);
        setFieldVisibility(mCardholderName, false);
//        setViewVisibility(mCardNumberIcon, mCardNumberRequired);
        setViewVisibility(mCardNumberIcon, false);
//        setFieldVisibility(mCardNumber, mCardNumberRequired);
        setFieldVisibility(mCardNumber, true);
//        setFieldVisibility(mExpiration, mExpirationRequired);
        setFieldVisibility(mExpiration, true);
//        setFieldVisibility(mCvv, mCvvRequired);
        setFieldVisibility(mCvv, true);
//        setViewVisibility(mPostalCodeIcon, mPostalCodeRequired);
        setViewVisibility(mPostalCodeIcon, false);
//        setFieldVisibility(mPostalCode, mPostalCodeRequired);
        setFieldVisibility(mPostalCode, false);
//        setViewVisibility(mMobileNumberIcon, mMobileNumberRequired);
        setViewVisibility(mMobileNumberIcon, false);
//        setFieldVisibility(mCountryCode, mMobileNumberRequired);
        setFieldVisibility(mCountryCode, false);
//        setFieldVisibility(mMobileNumber, mMobileNumberRequired);
        setFieldVisibility(mMobileNumber, false);
//        setViewVisibility(mMobileNumberExplanation, mMobileNumberRequired);
        setViewVisibility(mMobileNumberExplanation, false);
//        setViewVisibility(mSaveCardCheckBox, mSaveCardCheckBoxVisible);
        setViewVisibility(mSaveCardCheckBox, false);

        mCvv.setMask(true);

        TextInputEditText editText;
        for (int i = 0; i < mVisibleEditTexts.size(); i++) {
            editText = mVisibleEditTexts.get(i);
            if (i == mVisibleEditTexts.size() - 1) {
                editText.setImeOptions(EditorInfo.IME_ACTION_GO);
                editText.setImeActionLabel(mActionLabel, EditorInfo.IME_ACTION_GO);
                editText.setOnEditorActionListener(this);
            } else {
                editText.setImeOptions(EditorInfo.IME_ACTION_NEXT);
                editText.setImeActionLabel(null, EditorInfo.IME_ACTION_NONE);
                editText.setOnEditorActionListener(null);
            }
        }

        mSaveCardCheckBox.setInitiallyChecked(mSaveCardCheckBoxChecked);

        setVisibility(VISIBLE);
    }

    public void initTwoStep(
            Activity activity,
            ThreeDSOrderRequest orderRequest,
            int requestCode) {

        Intent intent = createCardPaymentIntent(activity, orderRequest);
        activity.startActivityForResult(intent, requestCode);
    }

    public void initThreeStep(
            Activity activity,
            ThreeDSOrderRequest orderRequest,
            int requestCode) {

        Intent intent = createCardPaymentIntent(activity, orderRequest);
        intent.putExtra("isThreeStep", true);

        activity.startActivityForResult(intent, requestCode);
    }

    private Intent createCardPaymentIntent(Activity activity, ThreeDSOrderRequest orderRequest) {
        Intent intent = new Intent(activity, CardPaymentActivity.class);
        intent.putExtra("request", orderRequest);
        intent.putExtra("card", getCard());

        return intent;
    }

    private Card getCard() {
        return Card.builder()
                .pan(getCardNumber())
                .expiryDate(getExpirationMonth() + getExpirationYear())
                .cvv(getCvv())
                .build();
    }

    /**
     * Sets the icon to the left of the card-holder name entry field, overriding the default icon.
     *
     * @param res The drawable resource for the card-holder name icon
     */
    private void setCardholderNameIcon(@DrawableRes int res) {
        mCardholderNameIcon.setImageResource(res);
    }

    /**
     * Sets the icon to the left of the card number entry field, overriding the default icon.
     *
     * @param res The drawable resource for the card number icon
     */
    private void setCardNumberIcon(@DrawableRes int res) {
        mCardNumberIcon.setImageResource(res);
    }

    /**
     * Sets the icon to the left of the postal code entry field, overriding the default icon.
     *
     * @param res The drawable resource for the postal code icon.
     */
    private void setPostalCodeIcon(@DrawableRes int res) {
        mPostalCodeIcon.setImageResource(res);
    }

    /**
     * Sets the icon to the left of the mobile number entry field, overriding the default icon.
     * <p>
     * If {@code null} is passed, the mobile number's icon will be hidden.
     *
     * @param res The drawable resource for the mobile number icon.
     */
    private void setMobileNumberIcon(@DrawableRes int res) {
        mMobileNumberIcon.setImageResource(res);
    }

    protected void setListeners(EditText editText) {
        editText.setOnFocusChangeListener(this);
        editText.setOnClickListener(this);
        editText.addTextChangedListener(this);
    }

    private void setViewVisibility(View view, boolean visible) {
        view.setVisibility(visible ? VISIBLE : GONE);
    }

    private void setFieldVisibility(ErrorEditText editText, boolean visible) {
        setViewVisibility(editText, visible);
        if (editText.getTextInputLayoutParent() != null) {
            setViewVisibility(editText.getTextInputLayoutParent(), visible);
        }

        if (visible) {
            mVisibleEditTexts.add(editText);
        } else {
            mVisibleEditTexts.remove(editText);
        }
    }

    /**
     * Set the listener to receive a callback when the card form becomes valid or invalid
     *
     * @param listener to receive the callback
     */
    public void setOnCardFormValidListener(OnCardFormValidListener listener) {
        mOnCardFormValidListener = listener;
    }

    /**
     * Set the listener to receive a callback when the card form should be submitted.
     * Triggered from a keyboard by a {@link EditorInfo#IME_ACTION_GO} event
     *
     * @param listener to receive the callback
     */
    public void setOnCardFormSubmitListener(OnCardFormSubmitListener listener) {
        mOnCardFormSubmitListener = listener;
    }

    /**
     * Set the listener to receive a callback when a field is focused
     *
     * @param listener to receive the callback
     */
    public void setOnFormFieldFocusedListener(OnCardFormFieldFocusedListener listener) {
        mOnCardFormFieldFocusedListener = listener;
    }

    /**
     * Set the listener to receive a callback when the {@link CardType} changes.
     *
     * @param listener to receive the callback
     */
    public void setOnCardTypeChangedListener(OnCardTypeChangedListener listener) {
        mOnCardTypeChangedListener = listener;
    }

    /**
     * Set {@link EditText} fields as enabled or disabled
     *
     * @param enabled {@code true} to enable all required fields, {@code false} to disable all required fields
     */
    public void setEnabled(boolean enabled) {
        mCardholderName.setEnabled(enabled);
        mCardNumber.setEnabled(enabled);
        mExpiration.setEnabled(enabled);
        mCvv.setEnabled(enabled);
        mPostalCode.setEnabled(enabled);
        mMobileNumber.setEnabled(enabled);
    }

    /**
     * @return {@code true} if all require fields are valid, otherwise {@code false}
     */
    public boolean isValid() {
        boolean valid = true;
        if (mCardholderNameStatus == FIELD_REQUIRED) {
            valid = valid && mCardholderName.isValid();
        }
        if (mCardNumberRequired) {
            valid = valid && mCardNumber.isValid();
        }
        if (mExpirationRequired) {
            valid = valid && mExpiration.isValid();
        }
        if (mCvvRequired) {
            valid = valid && mCvv.isValid();
        }
        if (mPostalCodeRequired) {
            valid = valid && mPostalCode.isValid();
        }
        if (mMobileNumberRequired) {
            valid = valid && mCountryCode.isValid() && mMobileNumber.isValid();
        }
        return valid;
    }

    /**
     * Validate all required fields and mark invalid fields with an error indicator
     */
    public void validate() {
        if (mCardholderNameStatus == FIELD_REQUIRED) {
            mCardholderName.validate();
        }
        if (mCardNumberRequired) {
            mCardNumber.validate();
        }
        if (mExpirationRequired) {
            mExpiration.validate();
        }
        if (mCvvRequired) {
            mCvv.validate();
        }
        if (mPostalCodeRequired) {
            mPostalCode.validate();
        }
        if (mMobileNumberRequired) {
            mCountryCode.validate();
            mMobileNumber.validate();
        }
    }

    /**
     * @return {@link CardholderNameEditText} view in the card form
     */
    private CardholderNameEditText getCardholderNameEditText() {
        return mCardholderName;
    }

    /**
     * @return {@link CardEditText} view in the card form
     */
    private CardEditText getCardEditText() {
        return mCardNumber;
    }

    /**
     * @return {@link ExpirationDateEditText} view in the card form
     */
    private ExpirationDateEditText getExpirationDateEditText() {
        return mExpiration;
    }

    /**
     * @return {@link CvvEditText} view in the card form
     */
    private CvvEditText getCvvEditText() {
        return mCvv;
    }

    /**
     * @return {@link PostalCodeEditText} view in the card form
     */
    private PostalCodeEditText getPostalCodeEditText() {
        return mPostalCode;
    }

    /**
     * @return {@link CountryCodeEditText} view in the card form
     */
    private CountryCodeEditText getCountryCodeEditText() {
        return mCountryCode;
    }

    /**
     * @return {@link MobileNumberEditText} view in the card form
     */
    private MobileNumberEditText getMobileNumberEditText() {
        return mMobileNumber;
    }

    /**
     * Set visual indicator on name to indicate error
     *
     * @param errorMessage the error message to display
     */
    private void setCardholderNameError(String errorMessage) {
        if (mCardholderNameStatus == FIELD_REQUIRED) {
            mCardholderName.setError(errorMessage);
            if (!mCardNumber.isFocused() && !mExpiration.isFocused() && !mCvv.isFocused()) {
                requestEditTextFocus(mCardholderName);
            }
        }
    }

    /**
     * Set visual indicator on card number to indicate error
     *
     * @param errorMessage the error message to display
     */
    public void setCardNumberError(String errorMessage) {
        if (mCardNumberRequired) {
            mCardNumber.setError(errorMessage);
            requestEditTextFocus(mCardNumber);
        }
    }

    /**
     * Set visual indicator on expiration to indicate error
     *
     * @param errorMessage the error message to display
     */
    public void setExpirationError(String errorMessage) {
        if (mExpirationRequired) {
            mExpiration.setError(errorMessage);
            if (!mCardNumber.isFocused()) {
                requestEditTextFocus(mExpiration);
            }
        }
    }

    /**
     * Set visual indicator on cvv to indicate error
     *
     * @param errorMessage the error message to display
     */
    public void setCvvError(String errorMessage) {
        if (mCvvRequired) {
            mCvv.setError(errorMessage);
            if (!mCardNumber.isFocused() && !mExpiration.isFocused()) {
                requestEditTextFocus(mCvv);
            }
        }
    }

    /**
     * Set visual indicator on postal code to indicate error
     *
     * @param errorMessage the error message to display
     */
    private void setPostalCodeError(String errorMessage) {
        if (mPostalCodeRequired) {
            mPostalCode.setError(errorMessage);
            if (!mCardNumber.isFocused() && !mExpiration.isFocused() && !mCvv.isFocused() && !mCardholderName.isFocused()) {
                requestEditTextFocus(mPostalCode);
            }
        }
    }

    /**
     * Set visual indicator on country code to indicate error
     *
     * @param errorMessage the error message to display
     */
    private void setCountryCodeError(String errorMessage) {
        if (mMobileNumberRequired) {
            mCountryCode.setError(errorMessage);
            if (!mCardNumber.isFocused() && !mExpiration.isFocused() && !mCvv.isFocused() && !mCardholderName.isFocused() && !mPostalCode.isFocused()) {
                requestEditTextFocus(mCountryCode);
            }
        }
    }

    /**
     * Set visual indicator on mobile number field to indicate error
     *
     * @param errorMessage the error message to display
     */
    private void setMobileNumberError(String errorMessage) {
        if (mMobileNumberRequired) {
            mMobileNumber.setError(errorMessage);
            if (!mCardNumber.isFocused() && !mExpiration.isFocused() && !mCvv.isFocused() && !mCardholderName.isFocused() && !mPostalCode.isFocused() && !mCountryCode.isFocused()) {
                requestEditTextFocus(mMobileNumber);
            }
        }
    }

    private void requestEditTextFocus(EditText editText) {
        editText.requestFocus();
        ((InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE))
                .showSoftInput(editText, InputMethodManager.SHOW_IMPLICIT);
    }

    /**
     * Attempt to close the soft keyboard. Will have no effect if the keyboard is not open.
     */
    private void closeSoftKeyboard() {
        mCardNumber.closeSoftKeyboard();
    }

    /**
     * @return the text in the cardholder name field
     */
    private String getCardholderName() {
        return mCardholderName.getText().toString();
    }

    /**
     * @return the text in the card number field
     */
    private String getCardNumber() {
        return mCardNumber.getText().toString();
    }

    /**
     * @return the 2-digit month, formatted with a leading zero if necessary from the expiration
     * field. If no month has been specified, an empty string is returned.
     */
    private String getExpirationMonth() {
        return mExpiration.getMonth();
    }

    /**
     * @return the 2- or 4-digit year depending on user input from the expiration field.
     * If no year has been specified, an empty string is returned.
     */
    private String getExpirationYear() {
        return mExpiration.getYear();
    }

    /**
     * @return the text in the cvv field
     */
    private String getCvv() {
        return mCvv.getText().toString();
    }

    /**
     * @return the text in the postal code field
     */
    private String getPostalCode() {
        return mPostalCode.getText().toString();
    }

    /**
     * @return the text in the country code field
     */
    private String getCountryCode() {
        return mCountryCode.getCountryCode();
    }

    /**
     * @return the unformatted text in the mobile number field
     */
    private String getMobileNumber() {
        return mMobileNumber.getMobileNumber();
    }

    /**
     * @return whether or not the save card CheckBox is checked
     */
    private boolean isSaveCardCheckBoxChecked() {
        return mSaveCardCheckBox.isChecked();
    }


    @Override
    public void onCardTypeChanged(CardType cardType) {
        mCvv.setCardType(cardType);

        if (mOnCardTypeChangedListener != null) {
            mOnCardTypeChangedListener.onCardTypeChanged(cardType);
        }
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
        if (hasFocus && mOnCardFormFieldFocusedListener != null) {
            mOnCardFormFieldFocusedListener.onCardFormFieldFocused(v);
        }
    }

    @Override
    public void onClick(View v) {
        if (mOnCardFormFieldFocusedListener != null) {
            mOnCardFormFieldFocusedListener.onCardFormFieldFocused(v);
        }
    }

    @Override
    public void afterTextChanged(Editable s) {
        boolean valid = isValid();
        if (mValid != valid) {
            mValid = valid;
            if (mOnCardFormValidListener != null) {
                mOnCardFormValidListener.onCardFormValid(valid);
            }
        }
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_GO && mOnCardFormSubmitListener != null) {
            mOnCardFormSubmitListener.onCardFormSubmit();
            return true;
        }
        return false;
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }
}
