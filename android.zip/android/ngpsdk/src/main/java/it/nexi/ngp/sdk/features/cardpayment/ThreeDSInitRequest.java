package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.enums.ExemptionsSettings;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.RecurringSettings;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSInitRequest implements Serializable {

    @SerializedName("order")
    private Order order;

    @SerializedName("card")
    private Card card;

    @SerializedName("recurrence")
    private RecurringSettings recurrence;

    @SerializedName("exemptions")
    private ExemptionsSettings exemptions;

    public ThreeDSInitRequest order(Order order) {
        this.order = order;
        return this;
    }

    public ThreeDSInitRequest card(Card card) {
        this.card = card;
        return this;
    }

    public ThreeDSInitRequest recurrence(RecurringSettings recurrence) {
        this.recurrence = recurrence;
        return this;
    }

    public ThreeDSInitRequest exemptions(ExemptionsSettings exemptions) {
        this.exemptions = exemptions;
        return this;
    }
}
