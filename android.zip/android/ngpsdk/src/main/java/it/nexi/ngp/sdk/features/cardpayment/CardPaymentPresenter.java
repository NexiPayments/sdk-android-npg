package it.nexi.ngp.sdk.features.cardpayment;

import it.nexi.ngp.sdk.shared.enums.CaptureType;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.util.Result;

class CardPaymentPresenter implements CardPaymentContracts.Presenter {

    private final CardPaymentContracts.View view;
    private final CardPaymentContracts.Repository repository;

    private ThreeDSOrderRequest threeDSOrderRequest;
    private ThreeDSInitResponse threeDSInitResponse;
    private ThreeDSAuthData threeDSAuthData;
    private Card creditCard;

    CardPaymentPresenter(final CardPaymentContracts.View view, final String returnUrl) {
        this.view = view;
        this.repository = new CardPaymentRepository(returnUrl, view.isThreeStep());
    }

    @Override
    public void initThreeDS(final ThreeDSOrderRequest orderRequest, final Card card) {
        view.showProgress();

        threeDSOrderRequest = orderRequest;
        creditCard = card;

        ThreeDSInitRequest initRequest =
            ThreeDSInitRequest.builder()
                    .order(orderRequest.getOrder())
                    .card(card)
                    .recurrence(orderRequest.getRecurrence())
                    .exemptions(orderRequest.getExemptions())
                    .build();

        repository.initThreeDS(initRequest, result -> {
            if (result instanceof Result.Success) {
                ThreeDSInitResponse response = ((Result.Success<ThreeDSInitResponse>) result).data;
                showThreeDS(response);
            } else {
                view.showInitErrorResult(result);
            }
        });
    }

    @Override
    public void processPaymentThreeDS() {
        view.showProgress();
        
        if (view.isThreeStep()) {
            validatePaymentThreeDS();
        } else {
            threeDSAuthData = ThreeDSAuthData.builder()
                    .threeDSAuthResponse(threeDSInitResponse.getThreeDSAuthRequest())
                    .build();
            doPaymentThreeDS();
        }
    }

    private void validatePaymentThreeDS() {
        ThreeDSValidationRequest validationRequest =
                ThreeDSValidationRequest.builder()
                        .operationId(threeDSInitResponse.getOperation().getOperationId())
                        .threeDSAuthResponse(threeDSInitResponse.getThreeDSAuthRequest())
                        .build();

        repository.validateThreeDS(validationRequest, result -> {
            if (result instanceof Result.Success) {
                ThreeDSValidationResponse response =
                        ((Result.Success<ThreeDSValidationResponse>) result).data;
                populateAuthData(response);
                doPaymentThreeDS();
            } else {
                view.showValidationErrorResult(result);
            }
        });
    }

    private void doPaymentThreeDS() {
        ThreeDSPaymentRequest paymentRequest =
                ThreeDSPaymentRequest.builder()
                        .operationId(threeDSInitResponse.getOperation().getOperationId())
                        .order(threeDSOrderRequest.getOrder())
                        .card(creditCard)
                        .recurrence(threeDSOrderRequest.getRecurrence())
                        .exemptions(threeDSOrderRequest.getExemptions())
                        .captureType(CaptureType.EXPLICIT)
                        .threeDSAuthData(threeDSAuthData)
                        .build();
        repository.processPaymentThreeDS(paymentRequest, result -> {
            if (result instanceof Result.Success) {
                view.showPaymentResult(result);
            } else {
                view.showPaymentResult(result);
            }
        });
    }

    private void populateAuthData(final ThreeDSValidationResponse response) {
        ThreeDSAuthResult authResult = response.getThreeDSAuthResult();
        threeDSAuthData =
                ThreeDSAuthData.builder()
                        .authenticationValue(authResult.getAuthenticationValue())
                        .eci(authResult.getEci())
                        .xid(authResult.getXid())
                        .build();
    }

    private void showThreeDS(final ThreeDSInitResponse response) {
        threeDSInitResponse = response;

        repository.getThreeDSHtmlPage(response, result -> {
            if (result instanceof Result.Success) {
                String htmlPage = ((Result.Success<String>) result).data;
                view.showWebView(htmlPage);
            } else {
                view.showHtmlPageErrorResult(result);
            }
        });
    }
}
