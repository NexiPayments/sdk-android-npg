package it.nexi.ngp.sdk.features.hostedpaymentpage;

import android.os.Handler;
import android.os.Looper;

import androidx.core.os.HandlerCompat;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import it.nexi.ngp.sdk.PaymentClientConfig;
import it.nexi.ngp.sdk.shared.models.Operation;
import it.nexi.ngp.sdk.shared.models.OrderDetails;
import it.nexi.ngp.sdk.util.HttpClient;
import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;
import it.nexi.ngp.sdk.util.ResultNotifier;
import it.nexi.ngp.sdk.util.UrlBuilder;

public class HostedPaymentPageRepository implements HostedPaymentPageContracts.Repository {

    private final String hppUrl;
    private final String hppEndpoint = "/api/phoenix-0.0/psp/api/v1/orders/hpp";

    private final String orderIdUrl;
    private final String orderIdEndpoint = "/api/phoenix-0.0/psp/api/v1/orders/";

    private final ExecutorService executorService;
    private final Handler handler;

    public HostedPaymentPageRepository() {
        String hostname = PaymentClientConfig.getInstance().getHostname();
        this.hppUrl = UrlBuilder.buildHttps(hostname, hppEndpoint);
        this.orderIdUrl = UrlBuilder.buildHttps(hostname, orderIdEndpoint);

        this.executorService = Executors.newSingleThreadExecutor();
        this.handler = HandlerCompat.createAsync(Looper.getMainLooper());
    }

    @Override
    public void initHostedPaymentPage(
        final CreateHostedOrderRequest request,
        final RepositoryCallback<CreateHostedOrderResponse> callback)
    {
        executorService.execute(() -> {
            try {
                Result<CreateHostedOrderResponse> result = makeInitHostedPaymentPageRequest(request);
                ResultNotifier.notifyResult(handler, result, callback);
            } catch (Exception e) {
                Result<CreateHostedOrderResponse> error = new Result.Error<>(e);
                ResultNotifier.notifyResult(handler, error, callback);
            }
        });
    }

    @Override
    public void getOperationResult(
            final String orderId,
            final RepositoryCallback<Operation> callback)
    {
        executorService.execute(() -> {
            try {
                Result<Operation> result = makeGetOperationResultRequest(orderId);
                ResultNotifier.notifyResult(handler, result, callback);
            } catch (Exception e) {
                Result<Operation> error = new Result.Error<>(e);
                ResultNotifier.notifyResult(handler, error, callback);
            }
        });
    }

    private Result<CreateHostedOrderResponse> makeInitHostedPaymentPageRequest(
        final CreateHostedOrderRequest request)
    {
        try {
            CreateHostedOrderResponse response =
                    new HttpClient(hppUrl).post(request, CreateHostedOrderResponse.class);
            return new Result.Success<>(response);
        } catch (Exception e) {
            return new Result.Error<>(e);
        }
    }

    private Result<Operation> makeGetOperationResultRequest(final String orderId) {
        try {
            String url = orderIdUrl + orderId;
            OrderDetails response = new HttpClient(url).get(OrderDetails.class);
            List<Operation> operations = response.getOperations();
            Operation result = operations.get(operations.size() - 1);
            return new Result.Success<>(result);
        } catch (Exception e) {
            return new Result.Error<>(e);
        }
    }
}
