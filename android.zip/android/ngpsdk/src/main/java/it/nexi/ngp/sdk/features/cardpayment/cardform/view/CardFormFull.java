package it.nexi.ngp.sdk.features.cardpayment.cardform.view;

import android.content.Context;
import android.util.AttributeSet;

import java.util.ArrayList;

import it.nexi.ngp.sdk.R;

public class CardFormFull extends CardForm {

    public CardFormFull(Context context) {
        super(context);
    }

    public CardFormFull(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public CardFormFull(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    public CardFormFull(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @Override
    void init() {
        setVisibility(GONE);
        setOrientation(VERTICAL);

        inflate(getContext(), R.layout.card_form_fields, this);

        mCardNumberIcon = findViewById(R.id.card_form_card_number_icon);
        mCardNumber = findViewById(R.id.card_form_card_number);
        mExpiration = findViewById(R.id.card_form_expiration);
        mCvv = findViewById(R.id.card_form_cvv);
        mCardholderName = findViewById(R.id.card_form_cardholder_name);
        mCardholderNameIcon = findViewById(R.id.card_form_cardholder_name_icon);
        mPostalCodeIcon = findViewById(R.id.card_form_postal_code_icon);
        mPostalCode = findViewById(R.id.card_form_postal_code);
        mMobileNumberIcon = findViewById(R.id.card_form_mobile_number_icon);
        mCountryCode = findViewById(R.id.card_form_country_code);
        mMobileNumber = findViewById(R.id.card_form_mobile_number);
        mMobileNumberExplanation = findViewById(R.id.card_form_mobile_number_explanation);
        mSaveCardCheckBox = findViewById(R.id.card_form_save_card_checkbox);

        mVisibleEditTexts = new ArrayList<>();

        setListeners(mCardholderName);
        setListeners(mCardNumber);
        setListeners(mExpiration);
        setListeners(mCvv);
        setListeners(mPostalCode);
        setListeners(mMobileNumber);

        mCardNumber.setOnCardTypeChangedListener(this);
    }
}
