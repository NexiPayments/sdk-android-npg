package it.nexi.ngp.sdk.io.errors;

import com.google.gson.annotations.SerializedName;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ClientError {

    @SerializedName("errors")
    private Errors errors;

    public ClientError errors(Errors errors) {
        this.errors = errors;
        return this;
    }
}
