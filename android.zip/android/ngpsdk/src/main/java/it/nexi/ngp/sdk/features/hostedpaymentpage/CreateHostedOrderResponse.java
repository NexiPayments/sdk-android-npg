package it.nexi.ngp.sdk.features.hostedpaymentpage;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateHostedOrderResponse implements Serializable {

    @SerializedName("hostedPage")
    private String hostedPage;

    @SerializedName("securityToken")
    private String securityToken;

    public CreateHostedOrderResponse hostedPage(String hostedPage) {
        this.hostedPage = hostedPage;
        return this;
    }

    public CreateHostedOrderResponse securityToken(String securityToken) {
        this.securityToken = securityToken;
        return this;
    }
}
