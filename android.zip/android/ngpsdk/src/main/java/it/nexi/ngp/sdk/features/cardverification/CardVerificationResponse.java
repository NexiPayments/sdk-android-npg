package it.nexi.ngp.sdk.features.cardverification;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.models.Operation;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CardVerificationResponse implements Serializable {

    @SerializedName("operation")
    private Operation operation;

    public CardVerificationResponse operation(Operation operation) {
        this.operation = operation;
        return this;
    }
}
