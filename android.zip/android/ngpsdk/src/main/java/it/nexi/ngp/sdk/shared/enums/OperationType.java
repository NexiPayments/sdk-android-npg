package it.nexi.ngp.sdk.shared.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.io.Serializable;

@JsonAdapter(OperationType.Adapter.class)
public enum OperationType implements Serializable {

    AUTHORIZATION("AUTHORIZATION"),
    CAPTURE("CAPTURE"),
    VOID("VOID"),
    REFUND("REFUND"),
    CANCEL("CANCEL");

    private String value;

    OperationType(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static OperationType fromValue(String input) {
        for (OperationType b : OperationType.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<OperationType> {
        @Override
        public void write(final JsonWriter jsonWriter, final OperationType enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public OperationType read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return OperationType.fromValue((String) (value));
        }
    }
}
