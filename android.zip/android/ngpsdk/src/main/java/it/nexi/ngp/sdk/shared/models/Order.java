package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Order implements Serializable {

    @SerializedName("orderId")
    private String orderId;

    @SerializedName("amount")
    private String amount;

    @SerializedName("installmentQty")
    private String installmentQty;

    @SerializedName("currency")
    private String currency;

    @SerializedName("customerId")
    private String customerId;

    @SerializedName("description")
    private String description;

    @SerializedName("customField")
    private String customField;

    @SerializedName("customerInfo")
    private CustomerInfo customerInfo;

    @SerializedName("transactionSummary")
    private List<TransactionSummary> transactionSummary;

    @SerializedName("installments")
    private List<Installment> installments;

    @SerializedName("termsAndConditionsIds")
    private TermsAndConditions termsAndConditionsIds;

    public Order orderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    public Order amount(String amount) {
        this.amount = amount;
        return this;
    }

    public Order installmentQty(String installmentQty) {
        this.installmentQty = Order.this.installmentQty;
        return this;
    }

    public Order currency(String currency) {
        this.currency = currency;
        return this;
    }

    public Order customerId(String customerId) {
        this.customerId = customerId;
        return this;
    }

    public Order description(String description) {
        this.description = description;
        return this;
    }

    public Order customField(String customField) {
        this.customField = customField;
        return this;
    }

    public Order customerInfo(CustomerInfo customerInfo) {
        this.customerInfo = customerInfo;
        return this;
    }

    public Order transactionSummary(List<TransactionSummary> transactionSummary) {
        this.transactionSummary = transactionSummary;
        return this;
    }

    public Order addTransactionSummaryItem(TransactionSummary transactionSummaryItem) {
        if (this.transactionSummary == null) {
            this.transactionSummary = new ArrayList<TransactionSummary>();
        }
        this.transactionSummary.add(transactionSummaryItem);
        return this;
    }

    public Order installments(List<Installment> installments) {
        this.installments = installments;
        return this;
    }

    public Order addInstallmentsItem(Installment installmentsItem) {
        if (this.installments == null) {
            this.installments = new ArrayList<Installment>();
        }
        this.installments.add(installmentsItem);
        return this;
    }

    public Order termsAndConditionsIds(TermsAndConditions termsAndConditionsIds) {
        this.termsAndConditionsIds = termsAndConditionsIds;
        return this;
    }
}
