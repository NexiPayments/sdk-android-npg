package it.nexi.ngp.sdk.shared.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;
import java.io.Serializable;

@JsonAdapter(ExemptionsSettings.Adapter.class)
public enum ExemptionsSettings implements Serializable {

    NO_PREFERENCE("NO_PREFERENCE"),
    CHALLENGE_REQUESTED("CHALLENGE_REQUESTED");

    private String value;

    ExemptionsSettings(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static ExemptionsSettings fromValue(String input) {
        for (ExemptionsSettings b : ExemptionsSettings.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<ExemptionsSettings> {
        @Override
        public void write(final JsonWriter jsonWriter, final ExemptionsSettings enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public ExemptionsSettings read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return ExemptionsSettings.fromValue((String) (value));
        }
    }
}
