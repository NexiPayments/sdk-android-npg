package it.nexi.ngp.sdk.features.paymentmethods;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.enums.PaymentMethodType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaymentMethod1 implements Serializable {

    @SerializedName("circuit")
    private String circuit;

    @SerializedName("methodType")
    private PaymentMethodType methodType;

    @SerializedName("imageLink")
    private String imageLink;

    @SerializedName("recurringSupported")
    private Boolean recurringSupported;

    @SerializedName("oneClickSupported")
    private Boolean oneClickSupported;

    public PaymentMethod1 circuit(String circuit) {
        this.circuit = circuit;
        return this;
    }

    public PaymentMethod1 methodType(PaymentMethodType methodType) {
        this.methodType = methodType;
        return this;
    }

    public PaymentMethod1 imageLink(String imageLink) {
        this.imageLink = imageLink;
        return this;
    }

    public PaymentMethod1 recurringSupported(Boolean recurringSupported) {
        this.recurringSupported = recurringSupported;
        return this;
    }

    public PaymentMethod1 oneClickSupported(Boolean oneClickSupported) {
        this.oneClickSupported = oneClickSupported;
        return this;
    }
}
