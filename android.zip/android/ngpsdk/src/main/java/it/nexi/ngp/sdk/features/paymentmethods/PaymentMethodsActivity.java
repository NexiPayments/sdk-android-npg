package it.nexi.ngp.sdk.features.paymentmethods;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import it.nexi.ngp.sdk.R;
import it.nexi.ngp.sdk.util.Result;

public class PaymentMethodsActivity
    extends AppCompatActivity
    implements PaymentMethodsContracts.View
{

    private TextView text;
    private ProgressBar progressBar;

    private PaymentMethodsContracts.Presenter presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment_methods);

        text = findViewById(R.id.text_view);
        progressBar = findViewById(R.id.progress_bar);

        presenter = new PaymentMethodsPresenter(this);
        presenter.getPaymentMethods();
    }

    @Override
    public void showProgress() {
        text.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.VISIBLE);
    }

    @Override
    public void showResult(Result<PaymentMethodsResponse> result) {
        text.setVisibility(View.INVISIBLE);
        progressBar.setVisibility(View.INVISIBLE);

        Intent intent = new Intent();
        intent.putExtra("request", getIntent().getSerializableExtra("request"));

        if (result instanceof Result.Success) {
            PaymentMethodsResponse response = ((Result.Success<PaymentMethodsResponse>) result).data;
            intent.putExtra("response", response);
            setResult(RESULT_OK, intent);
        } else {
            Exception exception = ((Result.Error<PaymentMethodsResponse>) result).exception;
            intent.putExtra("exception", exception);
            setResult(RESULT_CANCELED, intent);
        }

        finish();
    }
}
