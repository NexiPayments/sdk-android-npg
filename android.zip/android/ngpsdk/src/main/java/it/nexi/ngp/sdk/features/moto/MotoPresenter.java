package it.nexi.ngp.sdk.features.moto;

class MotoPresenter implements MotoContracts.Presenter {

    private final MotoContracts.View view;
    private final MotoContracts.Repository repository;

    MotoPresenter(MotoContracts.View view) {
        this.view = view;
        this.repository = new MotoRepository();
    }

    public void processMoto(final MotoRequest request) {
        view.showProgress();
        repository.processMoto(request, view::showResult);
    }
}
