package it.nexi.ngp.sdk.util;

public class UrlBuilder {

    public static String buildHttps(String hostname, String endpoint) {
        return "https://" + hostname + endpoint;
    }

    public static String buildHttp(String hostname, String endpoint) {
        return "http://" + hostname + endpoint;
    }
}
