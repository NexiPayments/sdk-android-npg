package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import it.nexi.ngp.sdk.io.errors.Warnings;
import it.nexi.ngp.sdk.shared.enums.ChannelType;
import it.nexi.ngp.sdk.shared.enums.OperationResult;
import it.nexi.ngp.sdk.shared.enums.OperationType;
import it.nexi.ngp.sdk.shared.enums.PaymentMethod;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Operation implements Serializable {

    @SerializedName("orderId")
    private String orderId;

    @SerializedName("operationId")
    private String operationId;

    @SerializedName("channel")
    private ChannelType channel;

    @SerializedName("operationType")
    private OperationType operationType;

    @SerializedName("operationResult")
    private OperationResult operationResult;

    @SerializedName("operationTime")
    private String operationTime;

    @SerializedName("paymentMethod")
    private PaymentMethod paymentMethod;

    @SerializedName("paymentCircuit")
    private String paymentCircuit;

    @SerializedName("paymentInstrumentInfo")
    private String paymentInstrumentInfo;

    @SerializedName("paymentEndToEndId")
    private String paymentEndToEndId;

    @SerializedName("cancelledOperationId")
    private String cancelledOperationId;

    @SerializedName("operationAmount")
    private String operationAmount;

    @SerializedName("operationCurrency")
    private String operationCurrency;

    @SerializedName("customerInfo")
    private CustomerInfo customerInfo;

    @SerializedName("warnings")
    private Warnings warnings;

    @SerializedName("paymentLinkId")
    private String paymentLinkId;

    @SerializedName("additionalData")
    private Map<String, String> additionalData;

    public Operation orderId(String orderId) {
        this.orderId = orderId;
        return this;
    }

    public Operation operationId(String operationId) {
        this.operationId = operationId;
        return this;
    }

    public Operation channel(ChannelType channel) {
        this.channel = channel;
        return this;
    }

    public Operation operationType(OperationType operationType) {
        this.operationType = operationType;
        return this;
    }

    public Operation operationResult(OperationResult operationResult) {
        this.operationResult = operationResult;
        return this;
    }

    public Operation operationTime(String operationTime) {
        this.operationTime = operationTime;
        return this;
    }

    public Operation paymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
        return this;
    }

    public Operation paymentCircuit(String paymentCircuit) {
        this.paymentCircuit = paymentCircuit;
        return this;
    }

    public Operation paymentInstrumentInfo(String paymentInstrumentInfo) {
        this.paymentInstrumentInfo = paymentInstrumentInfo;
        return this;
    }

    public Operation paymentEndToEndId(String paymentEndToEndId) {
        this.paymentEndToEndId = paymentEndToEndId;
        return this;
    }

    public Operation cancelledOperationId(String cancelledOperationId) {
        this.cancelledOperationId = cancelledOperationId;
        return this;
    }

    public Operation operationAmount(String operationAmount) {
        this.operationAmount = operationAmount;
        return this;
    }

    public Operation operationCurrency(String operationCurrency) {
        this.operationCurrency = operationCurrency;
        return this;
    }

    public Operation customerInfo(CustomerInfo customerInfo) {
        this.customerInfo = customerInfo;
        return this;
    }

    public Operation warnings(Warnings warnings) {
        this.warnings = warnings;
        return this;
    }

    public Operation paymentLinkId(String paymentLinkId) {
        this.paymentLinkId = paymentLinkId;
        return this;
    }

    public Operation additionalData(Map<String, String> additionalData) {
        this.additionalData = additionalData;
        return this;
    }

    public Operation putAdditionalDataItem(String key, String additionalDataItem) {
        if (this.additionalData == null) {
            this.additionalData = new HashMap<String, String>();
        }
        this.additionalData.put(key, additionalDataItem);
        return this;
    }
}
