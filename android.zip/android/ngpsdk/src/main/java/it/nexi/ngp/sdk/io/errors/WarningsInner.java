package it.nexi.ngp.sdk.io.errors;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class WarningsInner implements Serializable {

    @SerializedName("code")
    private String code;

    @SerializedName("description")
    private String description;

    public WarningsInner code(String code) {
        this.code = code;
        return this;
    }

    public WarningsInner description(String description) {
        this.description = description;
        return this;
    }
}
