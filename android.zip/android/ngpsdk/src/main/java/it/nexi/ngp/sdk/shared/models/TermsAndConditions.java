package it.nexi.ngp.sdk.shared.models;

import java.util.ArrayList;

import lombok.EqualsAndHashCode;
import lombok.ToString;

@ToString
@EqualsAndHashCode(callSuper = true)
public class TermsAndConditions extends ArrayList<String> {
}
