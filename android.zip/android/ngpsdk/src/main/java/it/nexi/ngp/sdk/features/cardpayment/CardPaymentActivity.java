package it.nexi.ngp.sdk.features.cardpayment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import it.nexi.ngp.sdk.R;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.util.Result;

public class CardPaymentActivity
    extends AppCompatActivity
    implements CardPaymentContracts.View
{

    private ProgressBar progressBar;
    private WebView webView;

    private CardPaymentContracts.Presenter presenter;

    private final String returnUrl = "https://npg.sdk.it/cardpayment/result";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        progressBar = findViewById(R.id.web_view_progress);
        webView = findViewById(R.id.web_view);

        presenter = new CardPaymentPresenter(this, returnUrl);

        ThreeDSOrderRequest orderRequest =
                (ThreeDSOrderRequest) getIntent().getSerializableExtra("request");
        Card card = (Card) getIntent().getSerializableExtra("card");
        presenter.initThreeDS(orderRequest, card);
    }

    @Override
    public void showProgress() {
        progressBar.setVisibility(View.VISIBLE);
        webView.setVisibility(WebView.INVISIBLE);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void showWebView(final String htmlPage) {
        progressBar.setVisibility(View.INVISIBLE);
        webView.setVisibility(WebView.VISIBLE);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webView.loadData(htmlPage, "text/html; charset=utf-8", "UTF-8");
        webView.setWebViewClient(new CardPaymentWebViewClient(returnUrl, () -> {
            presenter.processPaymentThreeDS();
        }));
    }

    @Override
    public void showInitErrorResult(final Result<ThreeDSInitResponse> result) {
        if (result instanceof Result.Success) {
            return;
        }

        Intent intent = new Intent();
        intent.putExtra("request", getIntent().getSerializableExtra("request"));

        Exception exception = ((Result.Error<ThreeDSInitResponse>) result).exception;
        intent.putExtra("exception", exception);
        setResult(RESULT_CANCELED, intent);

        finish();
    }

    @Override
    public void showHtmlPageErrorResult(final Result<String> result) {
        if (result instanceof Result.Success) {
            return;
        }

        Intent intent = new Intent();
        intent.putExtra("request", getIntent().getSerializableExtra("request"));

        Exception exception = ((Result.Error<String>) result).exception;
        intent.putExtra("exception", exception);
        setResult(RESULT_CANCELED, intent);

        finish();
    }

    @Override
    public void showValidationErrorResult(final Result<ThreeDSValidationResponse> result) {
        if (result instanceof Result.Success) {
            return;
        }

        Intent intent = new Intent();
        intent.putExtra("request", getIntent().getSerializableExtra("request"));

        Exception exception = ((Result.Error<ThreeDSValidationResponse>) result).exception;
        intent.putExtra("exception", exception);
        setResult(RESULT_CANCELED, intent);

        finish();
    }

    @Override
    public void showPaymentResult(final Result<ThreeDSPaymentResponse> result) {
        Intent intent = new Intent();
        intent.putExtra("request", getIntent().getSerializableExtra("request"));

        if (result instanceof Result.Success) {
            ThreeDSPaymentResponse response = ((Result.Success<ThreeDSPaymentResponse>) result).data;
            intent.putExtra("response", response);
            setResult(RESULT_OK, intent);
        } else {
            Exception exception = ((Result.Error<ThreeDSPaymentResponse>) result).exception;
            intent.putExtra("exception", exception);
            setResult(RESULT_CANCELED, intent);
        }

        finish();
    }

    @Override
    public boolean isThreeStep() {
        return getIntent().getBooleanExtra("isThreeStep", false);
    }
}
