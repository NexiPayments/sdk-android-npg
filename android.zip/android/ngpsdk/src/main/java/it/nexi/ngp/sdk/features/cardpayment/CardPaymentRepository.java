package it.nexi.ngp.sdk.features.cardpayment;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.core.os.HandlerCompat;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import it.nexi.ngp.sdk.PaymentClientConfig;
import it.nexi.ngp.sdk.io.UnexpectedStatusCodeException;
import it.nexi.ngp.sdk.util.HttpClient;
import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;
import it.nexi.ngp.sdk.util.ResultNotifier;
import it.nexi.ngp.sdk.util.UrlBuilder;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

class CardPaymentRepository implements CardPaymentContracts.Repository {

    private final String url;
    private final String returnUrl;
    private final ExecutorService executorService;
    private final Handler handler;

    CardPaymentRepository(String returnUrl, boolean isThreeStep) {
        this.returnUrl = returnUrl;

        String hostname = PaymentClientConfig.getInstance().getHostname();
        String endpoint =
            isThreeStep
            ? "/api/phoenix-0.0/psp/api/v1/orders/3steps/init"
            : "/api/phoenix-0.0/psp/api/v1/orders/2steps/init";
        this.url = UrlBuilder.buildHttps(hostname, endpoint);

        this.executorService = Executors.newSingleThreadExecutor();
        this.handler = HandlerCompat.createAsync(Looper.getMainLooper());
    }

    @Override
    public void initThreeDS(
        final ThreeDSInitRequest request,
        final RepositoryCallback<ThreeDSInitResponse> callback)
    {
        executorService.execute(() -> {
            try {
                Result<ThreeDSInitResponse> result = makeInitThreeDSRequest(request);
                ResultNotifier.notifyResult(handler, result, callback);
            } catch (Exception e) {
                Result<ThreeDSInitResponse> error = new Result.Error<>(e);
                ResultNotifier.notifyResult(handler, error, callback);
            }
        });
    }

    @Override
    public void getThreeDSHtmlPage(
        final ThreeDSInitResponse response,
        final RepositoryCallback<String> callback)
    {
        executorService.execute(() -> {
            try {
                Result<String> result = makeThreeDSHtmlPageFormRequest(response);
                ResultNotifier.notifyResult(handler, result, callback);
            } catch (Exception e) {
                Result<String> error = new Result.Error<>(e);
                ResultNotifier.notifyResult(handler, error, callback);
            }
        });
    }

    @Override
    public void validateThreeDS(
        final ThreeDSValidationRequest request,
        final RepositoryCallback<ThreeDSValidationResponse> callback)
    {
        executorService.execute(() -> {
            try {
                Result<ThreeDSValidationResponse> result = makeValidationThreeDSRequest(request);
                ResultNotifier.notifyResult(handler, result, callback);
            } catch (Exception e) {
                Result<ThreeDSValidationResponse> error = new Result.Error<>(e);
                ResultNotifier.notifyResult(handler, error, callback);
            }
        });
    }

    @Override
    public void processPaymentThreeDS(
        final ThreeDSPaymentRequest request,
        final RepositoryCallback<ThreeDSPaymentResponse> callback)
    {
        executorService.execute(() -> {
            try {
                Result<ThreeDSPaymentResponse> result = makePaymentThreeDSRequest(request);
                ResultNotifier.notifyResult(handler, result, callback);
            } catch (Exception e) {
                Result<ThreeDSPaymentResponse> error = new Result.Error<>(e);
                ResultNotifier.notifyResult(handler, error, callback);
            }
        });
    }

    private Result<ThreeDSInitResponse> makeInitThreeDSRequest(final ThreeDSInitRequest request) {
        try {
            ThreeDSInitResponse response =
                    new HttpClient(url).post(request, ThreeDSInitResponse.class);
            return new Result.Success<>(response);
        } catch (Exception e) {
            return new Result.Error<>(e);
        }
    }

    private Result<String> makeThreeDSHtmlPageFormRequest(final ThreeDSInitResponse initResponse) {
        try {
            ThreeDSFormRequest formRequest = ThreeDSFormRequest.builder()
                    .threeDSAuthRequest(initResponse.getThreeDSAuthRequest())
                    .returnUrl(returnUrl)
                    .transactionId(initResponse.getOperation().getOperationId())
                    .build();
            RequestBody body = new FormBody.Builder()
                    .add("threeDSAuthRequest", formRequest.getThreeDSAuthRequest())
                    .add("returnUrl", formRequest.getReturnUrl())
                    .add("transactionId", formRequest.getTransactionId())
                    .build();
            Request request = new Request.Builder()
                    .url(initResponse.getThreeDSAuthUrl())
                    .post(body)
                    .build();

            Log.d("HtmlPageRequest", request.toString());

            OkHttpClient client = new OkHttpClient().newBuilder().build();
            try (Response response = client.newCall(request).execute()) {
                if (!response.isSuccessful())
                    throw new UnexpectedStatusCodeException(
                            "The request generated an unexpected status code.\n" + response);

                return new Result.Success<>(response.body().string());
            }
        } catch (Exception e) {
            return new Result.Error<>(e);
        }
    }

    private Result<ThreeDSValidationResponse> makeValidationThreeDSRequest(
            final ThreeDSValidationRequest request)
    {
        try {
            ThreeDSValidationResponse response =
                    new HttpClient(url).post(request, ThreeDSValidationResponse.class);
            return new Result.Success<>(response);
        } catch (Exception e) {
            return new Result.Error<>(e);
        }
    }

    private Result<ThreeDSPaymentResponse> makePaymentThreeDSRequest(
            final ThreeDSPaymentRequest request)
    {
        try {
            ThreeDSPaymentResponse response =
                    new HttpClient(url).post(request, ThreeDSPaymentResponse.class);
            return new Result.Success<>(response);
        } catch (Exception e) {
            return new Result.Error<>(e);
        }
    }
}
