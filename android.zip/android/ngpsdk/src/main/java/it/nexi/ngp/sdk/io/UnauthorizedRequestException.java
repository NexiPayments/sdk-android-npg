package it.nexi.ngp.sdk.io;

public class UnauthorizedRequestException extends Exception {

    public UnauthorizedRequestException(String message) {
        super(message);
    }

    public UnauthorizedRequestException(String message, Throwable cause) {
        super(message, cause);
    }
}
