package it.nexi.ngp.sdk.features.hostedpaymentpage;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.PaymentSessionWebView;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateHostedOrderWebViewRequest implements Serializable {

    @SerializedName("order")
    private Order order;

    @SerializedName("paymentSession")
    private PaymentSessionWebView paymentSession;

    public CreateHostedOrderWebViewRequest order(Order order) {
        this.order = order;
        return this;
    }

    public CreateHostedOrderWebViewRequest paymentSession(PaymentSessionWebView paymentSession) {
        this.paymentSession = paymentSession;
        return this;
    }
}
