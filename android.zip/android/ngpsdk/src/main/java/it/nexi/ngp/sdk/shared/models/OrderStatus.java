package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import it.nexi.ngp.sdk.shared.enums.OperationType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderStatus {

    @SerializedName("order")
    private Order order;

    @SerializedName("authorizedAmount")
    private String authorizedAmount;

    @SerializedName("capturedAmount")
    private String capturedAmount;

    @SerializedName("lastOperationType")
    private OperationType lastOperationType;

    @SerializedName("lastOperationTime")
    private String lastOperationTime;

    public OrderStatus order(Order order) {
        this.order = order;
        return this;
    }

    public OrderStatus authorizedAmount(String authorizedAmount) {
        this.authorizedAmount = authorizedAmount;
        return this;
    }

    public OrderStatus capturedAmount(String capturedAmount) {
        this.capturedAmount = capturedAmount;
        return this;
    }

    public OrderStatus lastOperationType(OperationType lastOperationType) {
        this.lastOperationType = lastOperationType;
        return this;
    }

    public OrderStatus lastOperationTime(String lastOperationTime) {
        this.lastOperationTime = lastOperationTime;
        return this;
    }
}
