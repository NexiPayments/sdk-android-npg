package it.nexi.ngp.sdk.util;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import it.nexi.ngp.sdk.PaymentClientConfig;
import it.nexi.ngp.sdk.io.BadRequestException;
import it.nexi.ngp.sdk.io.InternalServerErrorException;
import it.nexi.ngp.sdk.io.UnauthorizedRequestException;
import it.nexi.ngp.sdk.io.UnexpectedStatusCodeException;
import it.nexi.ngp.sdk.io.errors.ClientError;
import it.nexi.ngp.sdk.io.errors.ServerError;
import it.nexi.ngp.sdk.io.errors.UnauthorizedError;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.logging.HttpLoggingInterceptor;

public class HttpClient {

    private final String url;
    private final String apiKey;

    public HttpClient(final String url) {
        this.url = url;
        this.apiKey = PaymentClientConfig.getInstance().getApiKey();
    }

    public <T> T post(Object requestObj, Class<T> responseClass)
        throws
            IOException,
            IllegalStateException,
            BadRequestException,
            UnauthorizedRequestException,
            InternalServerErrorException,
            UnexpectedStatusCodeException
    {
        Gson gson = new Gson();
        RequestBody body =
                RequestBody.create(MediaType.parse("application/json"), gson.toJson(requestObj));
        Request.Builder builder = new Request.Builder().method("POST", body);
        Request request = getRequestBuilderWithData(builder).build();
        return getResponse(responseClass, request);
    }

    public <T> T get(Class<T> responseClass)
        throws
            IOException,
            IllegalStateException,
            BadRequestException,
            UnauthorizedRequestException,
            InternalServerErrorException,
            UnexpectedStatusCodeException
    {
        Request.Builder builder = new Request.Builder().method("GET", null);
        Request request = getRequestBuilderWithData(builder).build();
        return getResponse(responseClass, request);
    }

    private Request.Builder getRequestBuilderWithData(Request.Builder builder) {
        String correlationId = UUID.randomUUID().toString();
        return
            builder
                .url(url)
                .addHeader("Correlation-Id", correlationId)
                .addHeader("X-Api-Key", apiKey)
                .addHeader("Content-Type", "application/json")
                .header("Connection", "close");
    }

    private OkHttpClient getHttpClient() {
        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

        return
            new OkHttpClient().newBuilder()
                .addInterceptor(interceptor)
                .retryOnConnectionFailure(true)
                .connectTimeout(10, TimeUnit.SECONDS)
                .writeTimeout(10, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .protocols(List.of(Protocol.HTTP_1_1))
                .build();
    }

    private <T> T getResponse(Class<T> responseClass, Request request)
            throws
            IOException,
            IllegalStateException,
            BadRequestException,
            UnauthorizedRequestException,
            InternalServerErrorException,
            UnexpectedStatusCodeException
    {
        OkHttpClient client = getHttpClient();
        try (Response response = client.newCall(request).execute()) {
            String responseBody = response.body().string();
            Gson gson = new Gson();

            switch (response.code()) {
                case 200:
                    return gson.fromJson(responseBody, responseClass);

                case 400:
                    ClientError clientError = gson.fromJson(responseBody, ClientError.class);
                    throw new BadRequestException(clientError.toString());

                case 401:
                    UnauthorizedError unauthorizedError = gson.fromJson(responseBody, UnauthorizedError.class);
                    throw new UnauthorizedRequestException(unauthorizedError.toString());

                case 500:
                    ServerError serverError = gson.fromJson(responseBody, ServerError.class);
                    throw new InternalServerErrorException(serverError.toString());

                default:
                    throw new UnexpectedStatusCodeException("The request generated an unexpected status code.");
            }
        }
    }
}
