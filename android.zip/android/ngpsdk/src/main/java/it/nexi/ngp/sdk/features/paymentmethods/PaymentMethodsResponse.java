package it.nexi.ngp.sdk.features.paymentmethods;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaymentMethodsResponse implements Serializable {

    @SerializedName("paymentMethods")
    private List<PaymentMethod1> paymentMethods;

    public PaymentMethodsResponse paymentMethods(List<PaymentMethod1> paymentMethods) {
        this.paymentMethods = paymentMethods;
        return this;
    }

    public PaymentMethodsResponse addPaymentMethodsItem(PaymentMethod1 paymentMethodsItem) {
        if (this.paymentMethods == null) {
            this.paymentMethods = new ArrayList<PaymentMethod1>();
        }
        this.paymentMethods.add(paymentMethodsItem);
        return this;
    }
}
