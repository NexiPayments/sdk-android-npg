package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CustomerInfo implements Serializable {

    @SerializedName("cardHolderName")
    private String cardHolderName;

    @SerializedName("cardHolderEmail")
    private String cardHolderEmail;

    @SerializedName("billingAddress")
    private Address billingAddress;

    @SerializedName("shippingAddress")
    private Address shippingAddress;

    @SerializedName("mobilePhoneCountryCode")
    private String mobilePhoneCountryCode;

    @SerializedName("mobilePhone")
    private String mobilePhone;

    @SerializedName("homePhone")
    private String homePhone;

    @SerializedName("workPhone")
    private String workPhone;

    @SerializedName("cardHolderAcctInfo")
    private CardHolderAccountInfo cardHolderAcctInfo;

    @SerializedName("merchantRiskIndicator")
    private MerchantRiskIndicator merchantRiskIndicator;

    public CustomerInfo cardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
        return this;
    }

    public CustomerInfo cardHolderEmail(String cardHolderEmail) {
        this.cardHolderEmail = cardHolderEmail;
        return this;
    }

    public CustomerInfo billingAddress(Address billingAddress) {
        this.billingAddress = billingAddress;
        return this;
    }

    public CustomerInfo shippingAddress(Address shippingAddress) {
        this.shippingAddress = shippingAddress;
        return this;
    }

    public CustomerInfo mobilePhoneCountryCode(String mobilePhoneCountryCode) {
        this.mobilePhoneCountryCode = mobilePhoneCountryCode;
        return this;
    }

    public CustomerInfo mobilePhone(String mobilePhone) {
        this.mobilePhone = mobilePhone;
        return this;
    }

    public CustomerInfo homePhone(String homePhone) {
        this.homePhone = homePhone;
        return this;
    }

    public CustomerInfo workPhone(String workPhone) {
        this.workPhone = workPhone;
        return this;
    }

    public CustomerInfo cardHolderAcctInfo(CardHolderAccountInfo cardHolderAcctInfo) {
        this.cardHolderAcctInfo = cardHolderAcctInfo;
        return this;
    }

    public CustomerInfo merchantRiskIndicator(MerchantRiskIndicator merchantRiskIndicator) {
        this.merchantRiskIndicator = merchantRiskIndicator;
        return this;
    }
}
