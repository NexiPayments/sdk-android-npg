package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.enums.RecurringAction;
import it.nexi.ngp.sdk.shared.enums.RecurringContractType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class RecurringSettings implements Serializable {

    @SerializedName("action")
    private RecurringAction action;

    @SerializedName("contractId")
    private String contractId;

    @SerializedName("contractType")
    private RecurringContractType contractType;

    @SerializedName("contractExpiryDate")
    private String contractExpiryDate;

    @SerializedName("contractFrequency")
    private String contractFrequency;

    public RecurringSettings action(RecurringAction action) {
        this.action = action;
        return this;
    }

    public RecurringSettings contractId(String contractId) {
        this.contractId = contractId;
        return this;
    }

    public RecurringSettings contractType(RecurringContractType contractType) {
        this.contractType = contractType;
        return this;
    }

    public RecurringSettings contractExpiryDate(String contractExpiryDate) {
        this.contractExpiryDate = contractExpiryDate;
        return this;
    }

    public RecurringSettings contractFrequency(String contractFrequency) {
        this.contractFrequency = contractFrequency;
        return this;
    }
}
