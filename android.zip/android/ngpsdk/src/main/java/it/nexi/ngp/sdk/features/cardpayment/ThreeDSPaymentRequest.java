package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.enums.CaptureType;
import it.nexi.ngp.sdk.shared.enums.ExemptionsSettings;
import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.RecurringSettings;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSPaymentRequest implements Serializable {

    @SerializedName("operationId")
    private String operationId;

    @SerializedName("order")
    private Order order;

    @SerializedName("card")
    private Card card;

    @SerializedName("recurrence")
    private RecurringSettings recurrence;

    @SerializedName("exemptions")
    private ExemptionsSettings exemptions;

    @SerializedName("captureType")
    private CaptureType captureType;

    @SerializedName("threeDSAuthData")
    private ThreeDSAuthData threeDSAuthData;

    public ThreeDSPaymentRequest operationId(String operationId) {
        this.operationId = operationId;
        return this;
    }

    public ThreeDSPaymentRequest order(Order order) {
        this.order = order;
        return this;
    }

    public ThreeDSPaymentRequest card(Card card) {
        this.card = card;
        return this;
    }

    public ThreeDSPaymentRequest recurrence(RecurringSettings recurrence) {
        this.recurrence = recurrence;
        return this;
    }

    public ThreeDSPaymentRequest exemptions(ExemptionsSettings exemptions) {
        this.exemptions = exemptions;
        return this;
    }

    public ThreeDSPaymentRequest captureType(CaptureType captureType) {
        this.captureType = captureType;
        return this;
    }

    public ThreeDSPaymentRequest threeDSAuthData(ThreeDSAuthData threeDSAuthData) {
        this.threeDSAuthData = threeDSAuthData;
        return this;
    }
}
