package it.nexi.ngp.sdk.features.paymentmethods;

class PaymentMethodsPresenter implements PaymentMethodsContracts.Presenter {

    private final PaymentMethodsContracts.View view;
    private final PaymentMethodsContracts.Repository repository;

    PaymentMethodsPresenter(final PaymentMethodsContracts.View view) {
        this.view = view;
        this.repository = new PaymentMethodsRepository();
    }

    @Override
    public void getPaymentMethods() {
        view.showProgress();
        repository.getPaymentMethods(view::showResult);
    }
}
