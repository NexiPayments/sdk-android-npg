package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSAuthData implements Serializable {

    @SerializedName("threeDSAuthResponse")
    private String threeDSAuthResponse;

    @SerializedName("authenticationValue")
    private String authenticationValue;

    @SerializedName("eci")
    private String eci;

    @SerializedName("xid")
    private String xid;

    public ThreeDSAuthData threeDSAuthResponse(String threeDSAuthResponse) {
        this.threeDSAuthResponse = threeDSAuthResponse;
        return this;
    }

    public ThreeDSAuthData authenticationValue(String authenticationValue) {
        this.authenticationValue = authenticationValue;
        return this;
    }

    public ThreeDSAuthData eci(String eci) {
        this.eci = eci;
        return this;
    }

    public ThreeDSAuthData xid(String xid) {
        this.xid = xid;
        return this;
    }
}
