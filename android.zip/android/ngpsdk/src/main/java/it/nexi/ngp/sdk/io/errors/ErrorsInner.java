package it.nexi.ngp.sdk.io.errors;

import androidx.annotation.NonNull;

import com.google.gson.annotations.SerializedName;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrorsInner {

    @SerializedName("code")
    private String code;

    @SerializedName("description")
    private String description;

    public ErrorsInner code(String code) {
        this.code = code;
        return this;
    }

    public ErrorsInner description(String description) {
        this.description = description;
        return this;
    }

    @NonNull
    @Override
    public String toString() {
        return "{\n" +
                "    code: " + toIndentedString(code) + "\n" +
                "    description: " + toIndentedString(description) + "\n" +
                "}";
    }

    /**
     * Convert the given object to string with each line indented by 4 spaces
     * (except the first line).
     */
    private String toIndentedString(Object o) {
        if (o == null) {
            return "null";
        }
        return o.toString().replace("\n", "\n    ");
    }

}
