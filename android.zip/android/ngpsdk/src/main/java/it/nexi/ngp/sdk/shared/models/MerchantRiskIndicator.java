package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;
import java.math.BigDecimal;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MerchantRiskIndicator implements Serializable {

    @SerializedName("deliveryEmail")
    private String deliveryEmail;

    @SerializedName("deliveryTimeframe")
    private String deliveryTimeframe;

    @SerializedName("giftCardAmount")
    private MerchantRiskIndicatorGiftCardAmount giftCardAmount;

    @SerializedName("giftCardCount")
    private BigDecimal giftCardCount;

    @SerializedName("preOrderDate")
    private String preOrderDate;

    @SerializedName("preOrderPurchaseIndicator")
    private String preOrderPurchaseIndicator;

    @SerializedName("reorderItemsIndicator")
    private String reorderItemsIndicator;

    @SerializedName("shipIndicator")
    private String shipIndicator;

    public MerchantRiskIndicator deliveryEmail(String deliveryEmail) {
        this.deliveryEmail = deliveryEmail;
        return this;
    }

    public MerchantRiskIndicator deliveryTimeframe(String deliveryTimeframe) {
        this.deliveryTimeframe = deliveryTimeframe;
        return this;
    }

    public MerchantRiskIndicator giftCardAmount(MerchantRiskIndicatorGiftCardAmount giftCardAmount) {
        this.giftCardAmount = giftCardAmount;
        return this;
    }

    public MerchantRiskIndicator giftCardCount(BigDecimal giftCardCount) {
        this.giftCardCount = giftCardCount;
        return this;
    }

    public MerchantRiskIndicator preOrderDate(String preOrderDate) {
        this.preOrderDate = preOrderDate;
        return this;
    }

    public MerchantRiskIndicator preOrderPurchaseIndicator(String preOrderPurchaseIndicator) {
        this.preOrderPurchaseIndicator = preOrderPurchaseIndicator;
        return this;
    }

    public MerchantRiskIndicator reorderItemsIndicator(String reorderItemsIndicator) {
        this.reorderItemsIndicator = reorderItemsIndicator;
        return this;
    }

    public MerchantRiskIndicator shipIndicator(String shipIndicator) {
        this.shipIndicator = shipIndicator;
        return this;
    }
}
