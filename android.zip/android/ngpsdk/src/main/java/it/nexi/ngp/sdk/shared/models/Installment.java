package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Installment implements Serializable {

    @SerializedName("date")
    private String date;

    @SerializedName("amount")
    private String amount;

    public Installment date(String date) {
        this.date = date;
        return this;
    }

    public Installment amount(String amount) {
        this.amount = amount;
        return this;
    }
}
