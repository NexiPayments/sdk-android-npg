package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Card implements Serializable {

    @SerializedName("pan")
    private String pan;

    @SerializedName("expiryDate")
    private String expiryDate;

    @SerializedName("cvv")
    private String cvv;

    public Card pan(String pan) {
        this.pan = pan;
        return this;
    }

    public Card expiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
        return this;
    }

    public Card cvv(String cvv) {
        this.cvv = cvv;
        return this;
    }
}
