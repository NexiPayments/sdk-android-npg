package it.nexi.ngp.sdk.io.errors;

import com.google.gson.annotations.SerializedName;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;


@Data
@Builder
@AllArgsConstructor
public class UnauthorizedError {

    @SerializedName("errcode")
    private String errcode;
    @SerializedName("errmsg")
    private String errmsg;

    public UnauthorizedError errcode(String errcode) {
        this.errcode = errcode;
        return this;
    }

    public UnauthorizedError errmsg(String errmsg) {
        this.errmsg = errmsg;
        return this;
    }
}
