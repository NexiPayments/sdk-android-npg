package it.nexi.ngp.sdk;

import android.app.Activity;
import android.content.Intent;

import it.nexi.ngp.sdk.features.cardpayment.CardPaymentActivity;
import it.nexi.ngp.sdk.features.cardpayment.ThreeDSOrderRequest;
import it.nexi.ngp.sdk.features.cardpayment.cardform.view.CardForm;
import it.nexi.ngp.sdk.features.cardverification.CardVerificationActivity;
import it.nexi.ngp.sdk.features.cardverification.CardVerificationRequest;
import it.nexi.ngp.sdk.features.hostedpaymentpage.CreateHostedOrderResponse;
import it.nexi.ngp.sdk.features.hostedpaymentpage.CreateHostedOrderWebViewRequest;
import it.nexi.ngp.sdk.features.hostedpaymentpage.HostedPaymentPageActivity;
import it.nexi.ngp.sdk.features.moto.MotoActivity;
import it.nexi.ngp.sdk.features.moto.MotoRequest;
import it.nexi.ngp.sdk.features.paymentmethods.PaymentMethodsActivity;
import it.nexi.ngp.sdk.io.InvalidApiKeyException;
import it.nexi.ngp.sdk.io.InvalidHostnameException;
import it.nexi.ngp.sdk.shared.models.Card;

public class PaymentClient {

    private final String hostname;
    private final String apiKey;

    /**
     *
     * @param hostname The hostname where the requests will be done.
     * @param apiKey The X-Api-Key to authorize the requests.
     * @throws InvalidHostnameException An invalid url has been given as hostname parameter.
     * @throws InvalidApiKeyException An invalid UUID has been given as api key parameter.
     */
    public PaymentClient(String hostname, String apiKey)
            throws InvalidHostnameException, InvalidApiKeyException
    {
        if (!isValidHostname(hostname)) {
            throw new InvalidHostnameException("The hostname is not valid.");
        }

        if (!isValidUUID(apiKey)) {
            throw new InvalidApiKeyException("The X-Api-Key is not valid.");
        }

        this.hostname = hostname;
        this.apiKey = apiKey;

        PaymentClientConfig.getInstance().setHostname(hostname);
        PaymentClientConfig.getInstance().setApiKey(apiKey);
    }

    /**
     * Creates a WebView that will load the Hosted Payment Page webpage.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link it.nexi.ngp.sdk.shared.models.Operation Operation} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity where the WebView will be created.
     * @param request The request DTO needed to make the api call.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void loadHostedPaymentPage(
        Activity activity,
        CreateHostedOrderWebViewRequest request,
        int requestCode)
    {
        Intent intent = new Intent(activity, HostedPaymentPageActivity.class);
        intent.putExtra("request", request);
        activity.startActivityForResult(intent, requestCode);
    }

    /**
     * Gets the result of an Hosted Payment Page api call.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link CreateHostedOrderResponse CreateHostedOrderResponse} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity.
     * @param request The request DTO needed to make the api call.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void createHostedPaymentPage(
        Activity activity,
        CreateHostedOrderWebViewRequest request,
        int requestCode)
    {
        Intent intent = new Intent(activity, HostedPaymentPageActivity.class);
        intent.putExtra("request", request);
        intent.putExtra("includeWebView", false);
        activity.startActivityForResult(intent, requestCode);
    }

    /**
     * Creates an Activity that will handle the two step payment process with 3DSecure.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link it.nexi.ngp.sdk.features.cardpayment.ThreeDSPaymentResponse ThreeDSPaymentResponse} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity.
     * @param cardForm The instance of the form to retrieve card details.
     * @param orderRequest The request DTO needed to make the init api call.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void loadTwoStepPaymentPage(
        Activity activity,
        CardForm cardForm,
        ThreeDSOrderRequest orderRequest,
        int requestCode)
    {
        if (!cardForm.isValid()) {
            cardForm.validate();
            return;
        }

        cardForm.initTwoStep(activity, orderRequest, requestCode);
    }

    /**
     * Creates an Activity that will handle the two step payment process with 3DSecure.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link it.nexi.ngp.sdk.features.cardpayment.ThreeDSPaymentResponse ThreeDSPaymentResponse} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity.
     * @param card The card details.
     * @param orderRequest The request DTO needed to make the init api call.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void loadTwoStepPaymentPage(
        Activity activity,
        Card card,
        ThreeDSOrderRequest orderRequest,
        int requestCode)
    {
        Intent intent = new Intent(activity, CardPaymentActivity.class);
        intent.putExtra("request", orderRequest);
        intent.putExtra("card", card);

        activity.startActivityForResult(intent, requestCode);
    }

    /**
     * Creates an Activity that will handle the three step payment process with 3DSecure.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link it.nexi.ngp.sdk.features.cardpayment.ThreeDSPaymentResponse ThreeDSPaymentResponse} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity.
     * @param cardForm The instance of the form to retrieve card details.
     * @param orderRequest The request DTO needed to make the init api call.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void loadThreeStepPaymentPage(
        Activity activity,
        CardForm cardForm,
        ThreeDSOrderRequest orderRequest,
        int requestCode)
    {
        if (!cardForm.isValid()) {
            cardForm.validate();
            return;
        }

        cardForm.initThreeStep(activity, orderRequest, requestCode);
    }

    /**
     * Creates an Activity that will handle the three step payment process with 3DSecure.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link it.nexi.ngp.sdk.features.cardpayment.ThreeDSPaymentResponse ThreeDSPaymentResponse} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity.
     * @param card The card details.
     * @param orderRequest The request DTO needed to make the init api call.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void loadThreeStepPaymentPage(
        Activity activity,
        Card card,
        ThreeDSOrderRequest orderRequest,
        int requestCode)
    {
        Intent intent = new Intent(activity, CardPaymentActivity.class);
        intent.putExtra("request", orderRequest);
        intent.putExtra("card", card);
        intent.putExtra("isThreeStep", true);

        activity.startActivityForResult(intent, requestCode);
    }

    /**
     * Creates an Activity that will verify a card.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link it.nexi.ngp.sdk.features.cardverification.CardVerificationResponse CardVerificationResponse} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity.
     * @param request The request DTO needed to make the api call.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void verifyCard(Activity activity, CardVerificationRequest request, int requestCode) {
        Intent intent = new Intent(activity, CardVerificationActivity.class);
        intent.putExtra("request", request);
        activity.startActivityForResult(intent, requestCode);
    }

    /**
     * Creates an Activity that will retrieve the payment methods available.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link it.nexi.ngp.sdk.features.paymentmethods.PaymentMethodsResponse PaymentMethodsResponse} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void getPaymentMethods(Activity activity, int requestCode) {
        Intent intent = new Intent(activity, PaymentMethodsActivity.class);
        activity.startActivityForResult(intent, requestCode);
    }

    /**
     * Creates an Activity that will handle the Mail Order Telephone Order process.
     * <p>Once the process will be done, an {@link Intent Intent} data will be available
     * in {@link Activity} onActivityResult method.</p>
     * <p>The result will vary based on the activity result received
     * an {@link it.nexi.ngp.sdk.features.moto.MotoResponse MotoResponse} object in it when
     * the result is OK, otherwise will contain a {@link Exception Exception} object.</p>
     * @param activity The starting activity.
     * @param request The request DTO needed to make the api call.
     * @param requestCode The request code where the activity result will sent data when the activity ends.
     */
    public void processMoto(Activity activity, MotoRequest request, int requestCode) {
        Intent intent = new Intent(activity, MotoActivity.class);
        intent.putExtra("request", request);
        activity.startActivityForResult(intent, requestCode);
    }

    private boolean isValidHostname(String hostname) {
        return hostname.matches("^(([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9\\-]*[a-zA-Z0-9])\\.)*([A-Za-z0-9]|[A-Za-z0-9][A-Za-z0-9\\-]*[A-Za-z0-9])$");
    }

    private boolean isValidUUID(String uuid) {
        return uuid.matches("^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$");
    }
}
