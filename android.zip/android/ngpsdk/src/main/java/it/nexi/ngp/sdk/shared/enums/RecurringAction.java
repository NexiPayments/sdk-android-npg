package it.nexi.ngp.sdk.shared.enums;

import com.google.gson.TypeAdapter;
import com.google.gson.annotations.JsonAdapter;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;

import java.io.IOException;

@JsonAdapter(RecurringAction.Adapter.class)
public enum RecurringAction {

    NO_RECURRING("NO_RECURRING"),
    SUBSEQUENT_PAYMENT("SUBSEQUENT_PAYMENT"),
    CONTRACT_CREATION("CONTRACT_CREATION"),
    CARD_SUBSTITUTION("CARD_SUBSTITUTION");

    private String value;

    RecurringAction(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }

    public static RecurringAction fromValue(String input) {
        for (RecurringAction b : RecurringAction.values()) {
            if (b.value.equals(input)) {
                return b;
            }
        }
        return null;
    }

    public static class Adapter extends TypeAdapter<RecurringAction> {
        @Override
        public void write(final JsonWriter jsonWriter, final RecurringAction enumeration) throws IOException {
            jsonWriter.value(String.valueOf(enumeration.getValue()));
        }

        @Override
        public RecurringAction read(final JsonReader jsonReader) throws IOException {
            Object value = jsonReader.nextString();
            return RecurringAction.fromValue((String) (value));
        }
    }
}
