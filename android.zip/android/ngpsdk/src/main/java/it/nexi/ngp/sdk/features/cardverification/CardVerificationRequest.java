package it.nexi.ngp.sdk.features.cardverification;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.shared.models.Order;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CardVerificationRequest implements Serializable {

    @SerializedName("order")
    private Order order;

    @SerializedName("card")
    private Card card;

    public CardVerificationRequest order(Order order) {
        this.order = order;
        return this;
    }

    public CardVerificationRequest card(Card card) {
        this.card = card;
        return this;
    }
}
