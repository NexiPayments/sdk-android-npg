package it.nexi.ngp.sdk.io;

public class InvalidHostnameException extends Exception {

    public InvalidHostnameException(String message) {
        super(message);
    }

    public InvalidHostnameException(String message, Throwable cause) {
        super(message, cause);
    }
}
