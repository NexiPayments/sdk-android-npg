package it.nexi.ngp.sdk.features.hostedpaymentpage;

import it.nexi.ngp.sdk.shared.models.Operation;
import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;

class HostedPaymentPageContracts {

    interface View {
        void showProgress();
        void showWebView(
            final CreateHostedOrderRequest request,
            final CreateHostedOrderResponse response,
            final String resultUrl,
            final String cancelUrl);
        void showInitResult(final Result<CreateHostedOrderResponse> result);
        void showOperationResult(final Result<Operation> result);
    }

    interface Presenter {
        void initHostedPaymentPage(final CreateHostedOrderWebViewRequest request, final boolean includeWebView);
        void getOperationResult(final String orderId);

        interface Callback {
            void onActionDone(int resultCode);
        }
    }

    interface Repository {
        void initHostedPaymentPage(
                final CreateHostedOrderRequest request,
                final RepositoryCallback<CreateHostedOrderResponse> callback);
        void getOperationResult(
                final String orderId,
                final RepositoryCallback<Operation> callback);
    }
}
