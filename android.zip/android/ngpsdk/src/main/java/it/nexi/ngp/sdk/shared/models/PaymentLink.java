package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaymentLink {

    @SerializedName("linkId")
    private String linkId;

    @SerializedName("amount")
    private String amount;

    @SerializedName("expirationDate")
    private String expirationDate;

    @SerializedName("link")
    private String link;

    @SerializedName("paidByOperationId")
    private String paidByOperationId;

    public PaymentLink linkId(String linkId) {
        this.linkId = linkId;
        return this;
    }

    public PaymentLink amount(String amount) {
        this.amount = amount;
        return this;
    }

    public PaymentLink expirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
        return this;
    }

    public PaymentLink link(String link) {
        this.link = link;
        return this;
    }

    public PaymentLink paidByOperationId(String paidByOperationId) {
        this.paidByOperationId = paidByOperationId;
        return this;
    }
}
