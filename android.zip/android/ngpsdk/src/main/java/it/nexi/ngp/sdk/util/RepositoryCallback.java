package it.nexi.ngp.sdk.util;

public interface RepositoryCallback<T> {
    void onComplete(Result<T> result);
}