package it.nexi.ngp.sdk.features.paymentmethods;

import android.os.Handler;
import android.os.Looper;

import androidx.core.os.HandlerCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import it.nexi.ngp.sdk.PaymentClientConfig;
import it.nexi.ngp.sdk.util.HttpClient;
import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;
import it.nexi.ngp.sdk.util.ResultNotifier;
import it.nexi.ngp.sdk.util.UrlBuilder;

class PaymentMethodsRepository implements PaymentMethodsContracts.Repository {

    private final String url;
    private final ExecutorService executorService;
    private final Handler handler;

    PaymentMethodsRepository() {
        String hostname = PaymentClientConfig.getInstance().getHostname();
        String endpoint = "/api/phoenix-0.0/psp/api/v1/payment_methods";
        this.url = UrlBuilder.buildHttps(hostname, endpoint);

        this.executorService = Executors.newSingleThreadExecutor();
        this.handler = HandlerCompat.createAsync(Looper.getMainLooper());
    }

    @Override
    public void getPaymentMethods(
        final RepositoryCallback<PaymentMethodsResponse> callback)
    {
        executorService.execute(() -> {
            try {
                Result<PaymentMethodsResponse> result = makeCardVerificationRequest();
                ResultNotifier.notifyResult(handler, result, callback);
            } catch (Exception e) {
                Result<PaymentMethodsResponse> error = new Result.Error<>(e);
                ResultNotifier.notifyResult(handler, error, callback);
            }
        });
    }

    private Result<PaymentMethodsResponse> makeCardVerificationRequest() {
        try {
            PaymentMethodsResponse response = new HttpClient(url).get(PaymentMethodsResponse.class);
            return new Result.Success<>(response);
        } catch (Exception e) {
            return new Result.Error<>(e);
        }
    }
}
