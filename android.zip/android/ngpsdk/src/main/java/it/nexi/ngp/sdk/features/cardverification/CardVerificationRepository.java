package it.nexi.ngp.sdk.features.cardverification;

import android.os.Handler;
import android.os.Looper;

import androidx.core.os.HandlerCompat;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import it.nexi.ngp.sdk.PaymentClientConfig;
import it.nexi.ngp.sdk.util.HttpClient;
import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;
import it.nexi.ngp.sdk.util.ResultNotifier;
import it.nexi.ngp.sdk.util.UrlBuilder;

class CardVerificationRepository implements CardVerificationContracts.Repository {

    private final String url;
    private final ExecutorService executorService;
    private final Handler handler;

    CardVerificationRepository() {
        String hostname = PaymentClientConfig.getInstance().getHostname();
        String endpoint = "/api/phoenix-0.0/psp/api/v1/orders/card_verification";
        this.url = UrlBuilder.buildHttps(hostname, endpoint);

        this.executorService = Executors.newSingleThreadExecutor();
        this.handler = HandlerCompat.createAsync(Looper.getMainLooper());
    }

    @Override
    public void verifyCard(
        CardVerificationRequest request,
        RepositoryCallback<CardVerificationResponse> callback)
    {
        executorService.execute(() -> {
            try {
                Result<CardVerificationResponse> result = makeCardVerificationRequest(request);
                ResultNotifier.notifyResult(handler, result, callback);
            } catch (Exception e) {
                Result<CardVerificationResponse> error = new Result.Error<>(e);
                ResultNotifier.notifyResult(handler, error, callback);
            }
        });
    }

    private Result<CardVerificationResponse> makeCardVerificationRequest(CardVerificationRequest request) {
        try {
            CardVerificationResponse response = new HttpClient(url).post(request, CardVerificationResponse.class);
            return new Result.Success<>(response);
        } catch (Exception e) {
            return new Result.Error<>(e);
        }
    }
}
