package it.nexi.ngp.sdk.util;

import android.os.Handler;

public class ResultNotifier {

    public static <T> void notifyResult(
        final Handler handler,
        final Result<T> result,
        final RepositoryCallback<T> callback)
    {
        handler.post(() -> callback.onComplete(result));
    }
}
