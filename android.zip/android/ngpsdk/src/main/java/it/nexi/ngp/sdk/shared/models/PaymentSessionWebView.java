package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.enums.ActionType;
import it.nexi.ngp.sdk.shared.enums.CaptureType;
import it.nexi.ngp.sdk.shared.enums.ExemptionsSettings;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PaymentSessionWebView implements Serializable {

    @SerializedName("actionType")
    private ActionType actionType;

    @SerializedName("amount")
    private String amount;

    @SerializedName("recurrence")
    private RecurringSettings recurrence;

    @SerializedName("captureType")
    private CaptureType captureType;

    @SerializedName("exemptions")
    private ExemptionsSettings exemptions;

    @SerializedName("language")
    private String language = "ita";

    @SerializedName("notificationUrl")
    private String notificationUrl;

    public PaymentSessionWebView actionType(ActionType actionType) {
        this.actionType = actionType;
        return this;
    }

    public PaymentSessionWebView amount(String amount) {
        this.amount = amount;
        return this;
    }

    public PaymentSessionWebView recurrence(RecurringSettings recurrence) {
        this.recurrence = recurrence;
        return this;
    }

    public PaymentSessionWebView captureType(CaptureType captureType) {
        this.captureType = captureType;
        return this;
    }

    public PaymentSessionWebView exemptions(ExemptionsSettings exemptions) {
        this.exemptions = exemptions;
        return this;
    }

    public PaymentSessionWebView language(String language) {
        this.language = language;
        return this;
    }

    public PaymentSessionWebView notificationUrl(String notificationUrl) {
        this.notificationUrl = notificationUrl;
        return this;
    }
}
