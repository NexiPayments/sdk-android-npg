package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Address implements Serializable {

    @SerializedName("name")
    private String name;

    @SerializedName("street")
    private String street;

    @SerializedName("additionalInfo")
    private String additionalInfo;

    @SerializedName("city")
    private String city;

    @SerializedName("postCode")
    private String postCode;

    @SerializedName("province")
    private String province;

    @SerializedName("country")
    private String country;

    public Address name(String name) {
        this.name = name;
        return this;
    }

    public Address street(String street) {
        this.street = street;
        return this;
    }

    public Address additionalInfo(String additionalInfo) {
        this.additionalInfo = additionalInfo;
        return this;
    }

    public Address city(String city) {
        this.city = city;
        return this;
    }

    public Address postCode(String postCode) {
        this.postCode = postCode;
        return this;
    }

    public Address province(String province) {
        this.province = province;
        return this;
    }

    public Address country(String country) {
        this.country = country;
        return this;
    }
}
