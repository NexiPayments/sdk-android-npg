package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSFormRequest implements Serializable {

    @SerializedName("threeDSAuthRequest")
    private String threeDSAuthRequest;

    @SerializedName("returnUrl")
    private String returnUrl;

    @SerializedName("transactionId")
    private String transactionId;

    public ThreeDSFormRequest threeDSAuthRequest(String threeDSAuthRequest) {
        this.threeDSAuthRequest = threeDSAuthRequest;
        return this;
    }

    public ThreeDSFormRequest returnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
        return this;
    }

    public ThreeDSFormRequest transactionId(String transactionId) {
        this.transactionId = transactionId;
        return this;
    }
}
