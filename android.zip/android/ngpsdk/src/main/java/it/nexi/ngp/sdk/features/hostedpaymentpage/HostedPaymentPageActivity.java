package it.nexi.ngp.sdk.features.hostedpaymentpage;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ProgressBar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import it.nexi.ngp.sdk.R;
import it.nexi.ngp.sdk.shared.models.Operation;
import it.nexi.ngp.sdk.util.Result;

public class HostedPaymentPageActivity
    extends AppCompatActivity
    implements HostedPaymentPageContracts.View
{

    private ProgressBar progressBar;
    private WebView webView;

    private HostedPaymentPageContracts.Presenter presenter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_view);

        progressBar = findViewById(R.id.web_view_progress);
        webView = findViewById(R.id.web_view);

        presenter = new HostedPaymentPagePresenter(this);

        boolean includeWebView = getIntent().getBooleanExtra("includeWebView", true);
        CreateHostedOrderWebViewRequest request =
                (CreateHostedOrderWebViewRequest) getIntent().getSerializableExtra("request");
        presenter.initHostedPaymentPage(request, includeWebView);
    }

    @Override
    public void showProgress() {
        progressBar.setVisibility(View.VISIBLE);
        webView.setVisibility(WebView.INVISIBLE);
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void showWebView(
            final CreateHostedOrderRequest request,
            final CreateHostedOrderResponse response,
            final String resultUrl,
            final String cancelUrl)
    {
        progressBar.setVisibility(View.INVISIBLE);
        webView.setVisibility(WebView.VISIBLE);

        WebSettings webSettings = webView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        webView.loadUrl(response.getHostedPage());
        webView.setWebViewClient(new HostedPaymentPageWebViewClient(resultUrl, cancelUrl, resultCode -> {
            if (resultCode == RESULT_OK) {
                presenter.getOperationResult(request.getOrder().getOrderId());
            } else {
                finish();
            }
        }));
    }

    @Override
    public void showInitResult(final Result<CreateHostedOrderResponse> result) {
        Intent intent = new Intent();
        intent.putExtra("request", getIntent().getSerializableExtra("request"));

        if (result instanceof Result.Success) {
            CreateHostedOrderResponse response = ((Result.Success<CreateHostedOrderResponse>) result).data;
            intent.putExtra("response", response);
            setResult(RESULT_OK, intent);
        } else {
            Exception exception = ((Result.Error<CreateHostedOrderResponse>) result).exception;
            intent.putExtra("exception", exception);
            setResult(RESULT_CANCELED, intent);
        }

        finish();
    }

    @Override
    public void showOperationResult(final Result<Operation> result) {
        Intent intent = new Intent();
        intent.putExtra("request", getIntent().getSerializableExtra("request"));

        if (result instanceof Result.Success) {
            Operation response = ((Result.Success<Operation>) result).data;
            intent.putExtra("response", response);
            setResult(RESULT_OK, intent);
        } else {
            Exception exception = ((Result.Error<Operation>) result).exception;
            intent.putExtra("exception", exception);
            setResult(RESULT_CANCELED, intent);
        }

        finish();
    }
}
