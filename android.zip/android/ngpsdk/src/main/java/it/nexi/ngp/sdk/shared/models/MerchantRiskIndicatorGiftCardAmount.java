package it.nexi.ngp.sdk.shared.models;

import com.google.gson.annotations.SerializedName;

import java.math.BigDecimal;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MerchantRiskIndicatorGiftCardAmount {

    @SerializedName("value")
    private BigDecimal value;

    @SerializedName("currency")
    private String currency;

    public MerchantRiskIndicatorGiftCardAmount value(BigDecimal value) {
        this.value = value;
        return this;
    }

    public MerchantRiskIndicatorGiftCardAmount currency(String currency) {
        this.currency = currency;
        return this;
    }
}
