package it.nexi.ngp.sdk.features.paymentmethods;

import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;

class PaymentMethodsContracts {

    interface View {
        void showProgress();
        void showResult(final Result<PaymentMethodsResponse> result);
    }

    interface Presenter {
        void getPaymentMethods();
    }

    interface Repository {
        void getPaymentMethods(
            final RepositoryCallback<PaymentMethodsResponse> callback);
    }
}
