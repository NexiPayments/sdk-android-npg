package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.models.Operation;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSPaymentResponse implements Serializable {

    @SerializedName("operation")
    private Operation operation;

    public ThreeDSPaymentResponse operation(Operation operation) {
        this.operation = operation;
        return this;
    }
}
