package it.nexi.ngp.sdk.features.moto;

import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;

class MotoContracts {

    interface View {
        void showProgress();
        void showResult(final Result<MotoResponse> result);
    }

    interface Presenter {
        void processMoto(final MotoRequest request);
    }

    interface Repository {
        void processMoto(
            final MotoRequest request,
            final RepositoryCallback<MotoResponse> callback);
    }
}
