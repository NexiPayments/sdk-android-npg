package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSAuthResult implements Serializable {

    @SerializedName("authenticationValue")
    private String authenticationValue;

    @SerializedName("cavvAlgorithm")
    private String cavvAlgorithm;

    @SerializedName("eci")
    private String eci;

    @SerializedName("merchantAcquirerBin")
    private String merchantAcquirerBin;

    @SerializedName("xid")
    private String xid;

    @SerializedName("status")
    private String status;

    @SerializedName("vendorcode")
    private String vendorcode;

    @SerializedName("version")
    private String version;

    public ThreeDSAuthResult authenticationValue(String authenticationValue) {
        this.authenticationValue = authenticationValue;
        return this;
    }

    public ThreeDSAuthResult cavvAlgorithm(String cavvAlgorithm) {
        this.cavvAlgorithm = cavvAlgorithm;
        return this;
    }

    public ThreeDSAuthResult eci(String eci) {
        this.eci = eci;
        return this;
    }

    public ThreeDSAuthResult merchantAcquirerBin(String merchantAcquirerBin) {
        this.merchantAcquirerBin = merchantAcquirerBin;
        return this;
    }

    public ThreeDSAuthResult xid(String xid) {
        this.xid = xid;
        return this;
    }

    public ThreeDSAuthResult status(String status) {
        this.status = status;
        return this;
    }

    public ThreeDSAuthResult vendorcode(String vendorcode) {
        this.vendorcode = vendorcode;
        return this;
    }

    public ThreeDSAuthResult version(String version) {
        this.version = version;
        return this;
    }
}
