package it.nexi.ngp.sdk.features.hostedpaymentpage;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.PaymentSession;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateHostedOrderRequest implements Serializable {

    @SerializedName("order")
    private Order order;

    @SerializedName("paymentSession")
    private PaymentSession paymentSession;

    public CreateHostedOrderRequest order(Order order) {
        this.order = order;
        return this;
    }

    public CreateHostedOrderRequest paymentSession(PaymentSession paymentSession) {
        this.paymentSession = paymentSession;
        return this;
    }
}
