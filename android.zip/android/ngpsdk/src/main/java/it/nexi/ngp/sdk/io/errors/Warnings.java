package it.nexi.ngp.sdk.io.errors;

import java.util.ArrayList;

import lombok.EqualsAndHashCode;
import lombok.ToString;

@ToString
@EqualsAndHashCode(callSuper = true)
public class Warnings extends ArrayList<WarningsInner> {
}
