package it.nexi.ngp.sdk.features.cardpayment;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

import it.nexi.ngp.sdk.shared.enums.ExemptionsSettings;
import it.nexi.ngp.sdk.shared.models.Order;
import it.nexi.ngp.sdk.shared.models.RecurringSettings;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ThreeDSOrderRequest implements Serializable {

    @SerializedName("order")
    private Order order;

    @SerializedName("recurrence")
    private RecurringSettings recurrence;

    @SerializedName("exemptions")
    private ExemptionsSettings exemptions;

    public ThreeDSOrderRequest order(Order order) {
        this.order = order;
        return this;
    }

    public ThreeDSOrderRequest recurrence(RecurringSettings recurrence) {
        this.recurrence = recurrence;
        return this;
    }

    public ThreeDSOrderRequest exemptions(ExemptionsSettings exemptions) {
        this.exemptions = exemptions;
        return this;
    }
}
