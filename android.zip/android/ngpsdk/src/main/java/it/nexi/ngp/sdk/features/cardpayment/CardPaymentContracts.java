package it.nexi.ngp.sdk.features.cardpayment;

import it.nexi.ngp.sdk.shared.models.Card;
import it.nexi.ngp.sdk.util.RepositoryCallback;
import it.nexi.ngp.sdk.util.Result;

class CardPaymentContracts {

    interface View {
        void showProgress();
        void showWebView(final String htmlPage);
        void showInitErrorResult(final Result<ThreeDSInitResponse> result);
        void showHtmlPageErrorResult(final Result<String> result);
        void showValidationErrorResult(final Result<ThreeDSValidationResponse> result);
        void showPaymentResult(final Result<ThreeDSPaymentResponse> result);
        boolean isThreeStep();
    }

    interface Presenter {
        void initThreeDS(final ThreeDSOrderRequest orderRequest, final Card card);
        void processPaymentThreeDS();

        interface Callback {
            void onActionDone();
        }
    }

    interface Repository {
        void initThreeDS(
            final ThreeDSInitRequest request,
            final RepositoryCallback<ThreeDSInitResponse> callback);
        void getThreeDSHtmlPage(
                final ThreeDSInitResponse response,
                final RepositoryCallback<String> callback);
        void validateThreeDS(
                final ThreeDSValidationRequest request,
                final RepositoryCallback<ThreeDSValidationResponse> callback);
        void processPaymentThreeDS(
                final ThreeDSPaymentRequest request,
                final RepositoryCallback<ThreeDSPaymentResponse> callback);
    }
}
